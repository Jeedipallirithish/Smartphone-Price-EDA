```python
!pip install missingno 
```

    Requirement already satisfied: missingno in c:\users\rithish\.anaconda\kkk\lib\site-packages (0.5.2)
    Requirement already satisfied: numpy in c:\users\rithish\.anaconda\kkk\lib\site-packages (from missingno) (1.26.4)
    Requirement already satisfied: matplotlib in c:\users\rithish\.anaconda\kkk\lib\site-packages (from missingno) (3.8.0)
    Requirement already satisfied: scipy in c:\users\rithish\.anaconda\kkk\lib\site-packages (from missingno) (1.11.4)
    Requirement already satisfied: seaborn in c:\users\rithish\.anaconda\kkk\lib\site-packages (from missingno) (0.12.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (4.25.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (23.1)
    Requirement already satisfied: pillow>=6.2.0 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (10.2.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from matplotlib->missingno) (2.8.2)
    Requirement already satisfied: six>=1.5 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from python-dateutil>=2.7->matplotlib->missingno) (1.16.0)
    Requirement already satisfied: pandas>=0.25 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from seaborn->missingno) (2.1.4)
    Requirement already satisfied: pytz>=2020.1 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from pandas>=0.25->seaborn->missingno) (2023.3.post1)
    Requirement already satisfied: tzdata>=2022.1 in c:\users\rithish\.anaconda\kkk\lib\site-packages (from pandas>=0.25->seaborn->missingno) (2023.3)
    


```python
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns 
import missingno as msno
import re
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
```

# Loading the data set


```python
d=pd.read_csv(r"C:\Users\Rithish\Downloads\mobiles1.csv")
```

### Data Understanding


```python
d.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 984 entries, 0 to 983
    Data columns (total 10 columns):
     #   Column     Non-Null Count  Dtype  
    ---  ------     --------------  -----  
     0   battery    984 non-null    object 
     1   camera     984 non-null    object 
     2   display    984 non-null    object 
     3   memory     984 non-null    object 
     4   name       984 non-null    object 
     5   price      984 non-null    int64  
     6   processor  983 non-null    object 
     7   rating     971 non-null    float64
     8   reviews    971 non-null    object 
     9   warranty   836 non-null    object 
    dtypes: float64(1), int64(1), object(8)
    memory usage: 77.0+ KB
    


```python
d.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>warranty</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mAh Battery</td>
      <td>12MP + 2MP | 8MP Front Camera</td>
      <td>15.8 cm (6.22 inch) HD+ Display</td>
      <td>4 GB RAM | 64 GB ROM | Expandable Upto 512 GB</td>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>9999</td>
      <td>Qualcomm Snapdragon 439 Processor</td>
      <td>4.4</td>
      <td>55,078 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
    </tr>
  </tbody>
</table>
</div>




```python
d.shape
```




    (984, 10)




```python
d.dtypes
```




    battery       object
    camera        object
    display       object
    memory        object
    name          object
    price          int64
    processor     object
    rating       float64
    reviews       object
    warranty      object
    dtype: object



#### Observation 
according to the data type in th edat aet there data type incorrection and we want to change the data according to the columns 



```python
df=d.copy()
```


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>984.000000</td>
      <td>971.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>15429.848577</td>
      <td>4.241195</td>
    </tr>
    <tr>
      <th>std</th>
      <td>12891.355967</td>
      <td>0.300296</td>
    </tr>
    <tr>
      <th>min</th>
      <td>887.000000</td>
      <td>2.700000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7499.000000</td>
      <td>4.100000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>11649.000000</td>
      <td>4.300000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>17999.250000</td>
      <td>4.400000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>104999.000000</td>
      <td>4.900000</td>
    </tr>
  </tbody>
</table>
</div>



### Observation 
the data set most of the price is range between the 984 to 1,04,999
and avg price of the moblie in the data set is the 15429.84 


```python
d.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>warranty</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mAh Battery</td>
      <td>12MP + 2MP | 8MP Front Camera</td>
      <td>15.8 cm (6.22 inch) HD+ Display</td>
      <td>4 GB RAM | 64 GB ROM | Expandable Upto 512 GB</td>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>9999</td>
      <td>Qualcomm Snapdragon 439 Processor</td>
      <td>4.4</td>
      <td>55,078 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
    </tr>
  </tbody>
</table>
</div>




```python
d1=df.copy()
```

### Data Cleaning and  Feature Engineering


```python
df["processor"] = df["processor"].astype(str)
df["processor"] = (
    df["processor"]
    .str.lower()
    .str.replace(r"[^a-zA-Z0-9\s\.]", "", regex=True)
    .str.strip()
)
# =========================
# REMOVE WRONG VALUES
# =========================
remove_pattern = r"warranty|year|months|replacement"
df = df[
    ~df["processor"].str.contains(
        remove_pattern,
        case=False,
        na=False
    )
]
# =========================
# PROCESSOR BRAND
# =========================
def get_processor_brand(x):

    if "snapdragon" in x or "qualcomm" in x:
        return "snapdragon"

    elif "mediatek" in x or "helio" in x or "mtk" in x:
        return "mediatek"

    elif "exynos" in x:
        return "exynos"

    elif "kirin" in x or "hisilicon" in x or "huawei" in x:
        return "kirin"

    elif "unisoc" in x:
        return "unisoc"

    elif "spreadtrum" in x:
        return "spreadtrum"

    else:
        return "other"

df["processor_brand"] = df["processor"].apply(get_processor_brand)
# =========================
# PROCESSOR SERIES
# =========================
# Examples:
# Snapdragon 720G -> 700
# Snapdragon 865 -> 800
# Helio G90T -> G90
# Exynos 9611 -> 9000
def get_processor_series(x):

    # Snapdragon Series
    snap = re.search(r"snapdragon\s*(\d{3})", x)

    if snap:
        num = snap.group(1)
        return num[0] + "00"

    # Helio G Series
    helio_g = re.search(r"g(\d+)", x)

    if helio_g:
        return "g" + helio_g.group(1)

    # Helio P Series
    helio_p = re.search(r"p(\d+)", x)

    if helio_p:
        return "p" + helio_p.group(1)

    # Exynos
    exynos = re.search(r"exynos\s*(\d{4})", x)

    if exynos:
        num = exynos.group(1)
        return num[0] + "000"

    return "unknown"

df["processor_series"] = df["processor"].apply(get_processor_series)
# ========================
# PROCESSOR TYPE
# =========================
# Gaming / Flagship / Budget
def get_processor_type(x):

    gaming_keywords = [
        "g90",
        "g95",
        "g96",
        "720g",
        "730g",
        "765g",
        "855",
        "865"
    ]

    flagship_keywords = [
        "855",
        "865",
        "888",
        "8 gen"
    ]

    if any(word in x for word in gaming_keywords):
        return "gaming"

    elif any(word in x for word in flagship_keywords):
        return "flagship"

    else:
        return "normal"

df["processor_type"] = df["processor"].apply(get_processor_type)
# =========================
# CORE TYPE
# =========================
def get_core_type(x):

    if "octa" in x:
        return "octa"

    elif "quad" in x:
        return "quad"

    elif "hexa" in x:
        return "hexa"

    else:
        return "unknown"

df["core_type"] = df["processor"].apply(get_core_type)

# =========================
# CLOCK SPEED
# =========================
# Extract values like:
# 2.3 GHz
# 1.95GHz
# 2 GHz
df["clock_speed"] = df["processor"].str.extract(
    r"(\d+\.?\d*)\s*ghz",
    expand=False
)
# Convert to float
df["clock_speed"] = df["clock_speed"].astype(float)
# =========================
# CHECK OUTPUT
# =========================
df[[
    "processor",
    "processor_brand",
    "processor_series",
    "processor_type",
    "core_type",
    "clock_speed"
]].head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>processor</th>
      <th>processor_brand</th>
      <th>processor_series</th>
      <th>processor_type</th>
      <th>core_type</th>
      <th>clock_speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>qualcomm snapdragon 439 processor</td>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>qualcomm snapdragon 439 processor</td>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>11</th>
      <td>qualcomm snapdragon 439 processor</td>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>12</th>
      <td>mediatek helio p22 octa core processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>13</th>
      <td>helio g70 processor</td>
      <td>mediatek</td>
      <td>g70</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>14</th>
      <td>helio g70 processor</td>
      <td>mediatek</td>
      <td>g70</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>15</th>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>mediatek helio g90t processor</td>
      <td>mediatek</td>
      <td>g90</td>
      <td>gaming</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>17</th>
      <td>qualcomm snapdragon 730g processor</td>
      <td>snapdragon</td>
      <td>700</td>
      <td>gaming</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>18</th>
      <td>mediatek helio p22 64 bit processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>19</th>
      <td>mediatek helio p22 64 bit processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>warranty</th>
      <th>processor_brand</th>
      <th>processor_series</th>
      <th>processor_type</th>
      <th>core_type</th>
      <th>clock_speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mAh Battery</td>
      <td>12MP + 2MP | 8MP Front Camera</td>
      <td>15.8 cm (6.22 inch) HD+ Display</td>
      <td>4 GB RAM | 64 GB ROM | Expandable Upto 512 GB</td>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>9999</td>
      <td>qualcomm snapdragon 439 processor</td>
      <td>4.4</td>
      <td>55,078 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5000 mAh Battery</td>
      <td>12MP + 8MP + 2MP + 2MP | 8MP Front Camera</td>
      <td>16.56 cm (6.52 inch) HD+ Display</td>
      <td>4 GB RAM | 64 GB ROM</td>
      <td>Realme 5i (Aqua Blue, 64 GB)</td>
      <td>10999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5000 mAh Battery</td>
      <td>12MP + 8MP + 2MP + 2MP | 8MP Front Camera</td>
      <td>16.56 cm (6.52 inch) HD+ Display</td>
      <td>4 GB RAM | 128 GB ROM</td>
      <td>Realme 5i (Aqua Blue, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5000 mAh Battery</td>
      <td>12MP + 8MP + 2MP + 2MP | 8MP Front Camera</td>
      <td>16.56 cm (6.52 inch) HD+ Display</td>
      <td>4 GB RAM | 128 GB ROM</td>
      <td>Realme 5i (Forest Green, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4000 mAh Battery</td>
      <td>13MP + 2MP | 5MP Front Camera</td>
      <td>15.49 cm (6.1 inch) HD+ Display</td>
      <td>3 GB RAM | 32 GB ROM | Expandable Upto 256 GB</td>
      <td>Realme C2 (Diamond Blue, 32 GB)</td>
      <td>7499</td>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>4.4</td>
      <td>10,091 Reviews</td>
      <td>Dual Nano SIM slots and Memory Card Slot</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>2300 mAh Li-Ion Polymer Battery</td>
      <td>8MP Rear Camera | 5MP Front Camera</td>
      <td>12.7 cm (5 inch) HD Display</td>
      <td>1 GB RAM | 16 GB ROM | Expandable Upto 128 GB</td>
      <td>Gionee P5L (Gold, 16 GB)</td>
      <td>4290</td>
      <td>quad core 1.3ghz processor</td>
      <td>3.7</td>
      <td>201 Reviews</td>
      <td>Brand Warranty of 1 Year</td>
      <td>other</td>
      <td>unknown</td>
      <td>normal</td>
      <td>quad</td>
      <td>1.3</td>
    </tr>
    <tr>
      <th>980</th>
      <td>2680 mAh Li-Ion Battery</td>
      <td>13MP Rear Camera | 5MP Front Camera</td>
      <td>13.21 cm (5.2 inch) Full HD Display</td>
      <td>3 GB RAM | 32 GB ROM</td>
      <td>Nextbit Robin (Ember, 32 GB)</td>
      <td>19999</td>
      <td>qualcomm snapdragon 808 msm8992 processor</td>
      <td>4.0</td>
      <td>516 Reviews</td>
      <td>Brand Warranty of 1 Year</td>
      <td>snapdragon</td>
      <td>800</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>981</th>
      <td>4550 mAh Battery</td>
      <td>13MP + 5MP | 20MP Front Camera</td>
      <td>15.24 cm (6 inch) Full HD Display</td>
      <td>4 GB RAM | 64 GB ROM | Expandable Upto 256 GB</td>
      <td>Gionee A1 Plus (Mocha Gold, 64 GB)</td>
      <td>10499</td>
      <td>helio p25 mt 6757cd processor</td>
      <td>4.1</td>
      <td>710 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>mediatek</td>
      <td>p25</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>982</th>
      <td>2100 mAh Li-Ion Battery</td>
      <td>8MP Rear Camera | 2MP Front Camera</td>
      <td>12.7 cm (5 inch) HD Display</td>
      <td>1 GB RAM | 8 GB ROM | Expandable Upto 32 GB</td>
      <td>XOLO Omega 5.0 (Black, 8 GB)</td>
      <td>8990</td>
      <td>mtk 6592m processor</td>
      <td>3.8</td>
      <td>81 Reviews</td>
      <td>1 Year Manufacturer Warranty</td>
      <td>mediatek</td>
      <td>unknown</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>983</th>
      <td>3000 mAh Battery</td>
      <td>12MP Rear Camera | 8MP Front Camera</td>
      <td>14.73 cm (5.8 inch) Quad HD+ Display</td>
      <td>4 GB RAM | 256 GB ROM | Expandable Upto 400 GB</td>
      <td>Samsung Galaxy S9 (Midnight Black, 256 GB)</td>
      <td>65900</td>
      <td>exynos 9810 processor</td>
      <td>4.4</td>
      <td>2,331 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>exynos</td>
      <td>9000</td>
      <td>normal</td>
      <td>unknown</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 15 columns</p>
</div>




```python
df[[
    "processor",
    "processor_brand",
    "processor_series",
    "processor_type",
    "core_type",
    "clock_speed"
]].isnull().sum()
```




    processor             0
    processor_brand       0
    processor_series      0
    processor_type        0
    core_type             0
    clock_speed         678
    dtype: int64




```python
df.drop(columns=["clock_speed"], inplace=True)
```


```python
# ==========================================
# CAMERA COLUMN COMPLETE FEATURE ENGINEERING
# ==========================================

import re
import numpy as np
import pandas as pd

# ------------------------------------------
# COPY DATAFRAME
# ------------------------------------------

df = df.copy()

# ------------------------------------------
# CLEAN CAMERA COLUMN
# ------------------------------------------

df["camera"] = (
    df["camera"]
    .astype(str)
    .str.lower()
    .str.replace(r"[^a-zA-Z0-9\s\+\|\.]", "", regex=True)
    .str.strip()
)

# ------------------------------------------
# FUNCTION TO EXTRACT REAR CAMERAS
# ------------------------------------------

def extract_rear_cameras(text):

    try:

        rear_part = str(text).split("|")[0]

        values = re.findall(r'(\d+\.?\d*)\s*mp', rear_part)

        values = [float(v) for v in values]

        # fill remaining with 0
        while len(values) < 4:
            values.append(0)

        return values[:4]

    except:
        return [0, 0, 0, 0]
# ------------------------------------------
# CREATE REAR CAMERA COLUMNS
# ------------------------------------------

df[[
    "rear_cam_1",
    "rear_cam_2",
    "rear_cam_3",
    "rear_cam_4"
]] = df["camera"].apply(
    lambda x: pd.Series(extract_rear_cameras(x))
)

# ------------------------------------------
# EXTRACT FRONT CAMERA
# ------------------------------------------

df["front_camera"] = df["camera"].str.extract(
    r'\|\s*(\d+\.?\d*)\s*mp',
    expand=False
)

df["front_camera"] = df["front_camera"].astype(float)

# ------------------------------------------
# COUNT NUMBER OF REAR CAMERAS
# ------------------------------------------

df["rear_camera_count"] = (
    df[[
        "rear_cam_1",
        "rear_cam_2",
        "rear_cam_3",
        "rear_cam_4"
    ]] > 0
).sum(axis=1)

# ------------------------------------------
# CAMERA TYPE
# ------------------------------------------

def get_camera_type(count):

    if count == 1:
        return "single"

    elif count == 2:
        return "dual"

    elif count == 3:
        return "triple"

    elif count >= 4:
        return "quad"

    else:
        return "unknown"

df["camera_type"] = df["rear_camera_count"].apply(get_camera_type)
```

                                                   camera  rear_cam_1  rear_cam_2  \
    0                       12mp + 2mp | 8mp front camera        12.0         2.0   
    1           12mp + 8mp + 2mp + 2mp | 8mp front camera        12.0         8.0   
    2           12mp + 8mp + 2mp + 2mp | 8mp front camera        12.0         8.0   
    3           12mp + 8mp + 2mp + 2mp | 8mp front camera        12.0         8.0   
    4                       13mp + 2mp | 5mp front camera        13.0         2.0   
    5                       13mp + 2mp | 5mp front camera        13.0         2.0   
    6                       13mp + 2mp | 5mp front camera        13.0         2.0   
    7                       13mp + 2mp | 5mp front camera        13.0         2.0   
    8           12mp + 8mp + 2mp + 2mp | 8mp front camera        12.0         8.0   
    9                       13mp + 2mp | 5mp front camera        13.0         2.0   
    10                      12mp + 2mp | 8mp front camera        12.0         2.0   
    11                      12mp + 2mp | 8mp front camera        12.0         2.0   
    12  16 mp + 5 mp + 2 mp + ai lens | 16mp front camera        16.0         5.0   
    13                      12mp + 2mp | 5mp front camera        12.0         2.0   
    14                      12mp + 2mp | 5mp front camera        12.0         2.0   
    15                      13mp + 2mp | 5mp front camera        13.0         2.0   
    16         64mp + 8mp + 2mp + 2mp | 16mp front camera        64.0         8.0   
    17  64mp + 8mp + 2mp + 2mp | 20mp + 2mp dual front...        64.0         8.0   
    18  13 mp + 2 mp + 2 mp + low light sensor | 8mp f...        13.0         2.0   
    19  13 mp + 2 mp + 2 mp + low light sensor | 8mp f...        13.0         2.0   
    
        rear_cam_3  rear_cam_4  front_camera  rear_camera_count camera_type  
    0          0.0         0.0           8.0                  2        dual  
    1          2.0         2.0           8.0                  4        quad  
    2          2.0         2.0           8.0                  4        quad  
    3          2.0         2.0           8.0                  4        quad  
    4          0.0         0.0           5.0                  2        dual  
    5          0.0         0.0           5.0                  2        dual  
    6          0.0         0.0           5.0                  2        dual  
    7          0.0         0.0           5.0                  2        dual  
    8          2.0         2.0           8.0                  4        quad  
    9          0.0         0.0           5.0                  2        dual  
    10         0.0         0.0           8.0                  2        dual  
    11         0.0         0.0           8.0                  2        dual  
    12         2.0         0.0          16.0                  3      triple  
    13         0.0         0.0           5.0                  2        dual  
    14         0.0         0.0           5.0                  2        dual  
    15         0.0         0.0           5.0                  2        dual  
    16         2.0         2.0          16.0                  4        quad  
    17         2.0         2.0          20.0                  4        quad  
    18         2.0         0.0           8.0                  3      triple  
    19         2.0         0.0           8.0                  3      triple  
    


```python
df[["camera","rear_cam_1",	"rear_cam_2",	"rear_cam_3",	"rear_cam_4",	"front_camera",	"rear_camera_count",	"camera_type"]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>camera</th>
      <th>rear_cam_1</th>
      <th>rear_cam_2</th>
      <th>rear_cam_3</th>
      <th>rear_cam_4</th>
      <th>front_camera</th>
      <th>rear_camera_count</th>
      <th>camera_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12mp + 2mp | 8mp front camera</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>2</td>
      <td>dual</td>
    </tr>
    <tr>
      <th>1</th>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
    </tr>
    <tr>
      <th>3</th>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
    </tr>
    <tr>
      <th>4</th>
      <td>13mp + 2mp | 5mp front camera</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>2</td>
      <td>dual</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>8mp rear camera | 5mp front camera</td>
      <td>8.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>1</td>
      <td>single</td>
    </tr>
    <tr>
      <th>980</th>
      <td>13mp rear camera | 5mp front camera</td>
      <td>13.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>1</td>
      <td>single</td>
    </tr>
    <tr>
      <th>981</th>
      <td>13mp + 5mp | 20mp front camera</td>
      <td>13.0</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>20.0</td>
      <td>2</td>
      <td>dual</td>
    </tr>
    <tr>
      <th>982</th>
      <td>8mp rear camera | 2mp front camera</td>
      <td>8.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>1</td>
      <td>single</td>
    </tr>
    <tr>
      <th>983</th>
      <td>12mp rear camera | 8mp front camera</td>
      <td>12.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>1</td>
      <td>single</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 8 columns</p>
</div>




```python
# -----------------------------------
# BATTERY FEATURE ENGINEERING
# -----------------------------------

df = df.copy()

# clean battery column

df["battery"] = (
    df["battery"]
    .astype(str)
    .str.lower()
    .str.strip()
)

# extract numeric battery value

df["battery_capacity"] = df["battery"].str.extract(
    r'(\d+)',
    expand=False
)

# convert to numeric

df["battery_capacity"] = pd.to_numeric(
    df["battery_capacity"],
    errors="coerce"
)

```

                                     battery  battery_capacity
    0                       5000 mah battery              5000
    1                       5000 mah battery              5000
    2                       5000 mah battery              5000
    3                       5000 mah battery              5000
    4                       4000 mah battery              4000
    5                       4000 mah battery              4000
    6                       4000 mah battery              4000
    7                       4000 mah battery              4000
    8                       5000 mah battery              5000
    9                       4000 mah battery              4000
    10                      5000 mah battery              5000
    11                      5000 mah battery              5000
    12       6000 mah li-ion polymer battery              6000
    13                      5000 mah battery              5000
    14                      5000 mah battery              5000
    15                      4000 mah battery              4000
    16                      4300 mah battery              4300
    17  4500 mah lithium-ion polymer battery              4500
    18       5000 mah li-ion polymer battery              5000
    19       5000 mah li-ion polymer battery              5000
    


```python
df[[
    "battery",
    "battery_capacity"
]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>battery_capacity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mah battery</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5000 mah battery</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5000 mah battery</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5000 mah battery</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4000 mah battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>2300 mah li-ion polymer battery</td>
      <td>2300</td>
    </tr>
    <tr>
      <th>980</th>
      <td>2680 mah li-ion battery</td>
      <td>2680</td>
    </tr>
    <tr>
      <th>981</th>
      <td>4550 mah battery</td>
      <td>4550</td>
    </tr>
    <tr>
      <th>982</th>
      <td>2100 mah li-ion battery</td>
      <td>2100</td>
    </tr>
    <tr>
      <th>983</th>
      <td>3000 mah battery</td>
      <td>3000</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 2 columns</p>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>warranty</th>
      <th>...</th>
      <th>processor_type</th>
      <th>core_type</th>
      <th>rear_cam_1</th>
      <th>rear_cam_2</th>
      <th>rear_cam_3</th>
      <th>rear_cam_4</th>
      <th>front_camera</th>
      <th>rear_camera_count</th>
      <th>camera_type</th>
      <th>battery_capacity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mah battery</td>
      <td>12mp + 2mp | 8mp front camera</td>
      <td>15.8 cm (6.22 inch) HD+ Display</td>
      <td>4 GB RAM | 64 GB ROM | Expandable Upto 512 GB</td>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>9999</td>
      <td>qualcomm snapdragon 439 processor</td>
      <td>4.4</td>
      <td>55,078 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>2</td>
      <td>dual</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) HD+ Display</td>
      <td>4 GB RAM | 64 GB ROM</td>
      <td>Realme 5i (Aqua Blue, 64 GB)</td>
      <td>10999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) HD+ Display</td>
      <td>4 GB RAM | 128 GB ROM</td>
      <td>Realme 5i (Aqua Blue, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) HD+ Display</td>
      <td>4 GB RAM | 128 GB ROM</td>
      <td>Realme 5i (Forest Green, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4000 mah battery</td>
      <td>13mp + 2mp | 5mp front camera</td>
      <td>15.49 cm (6.1 inch) HD+ Display</td>
      <td>3 GB RAM | 32 GB ROM | Expandable Upto 256 GB</td>
      <td>Realme C2 (Diamond Blue, 32 GB)</td>
      <td>7499</td>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>4.4</td>
      <td>10,091 Reviews</td>
      <td>Dual Nano SIM slots and Memory Card Slot</td>
      <td>...</td>
      <td>normal</td>
      <td>octa</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>2</td>
      <td>dual</td>
      <td>4000</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>




```python
# ======================================
# DISPLAY COLUMN FEATURE ENGINEERING
# ======================================

import pandas as pd
import numpy as np

df = df.copy()

# --------------------------------------
# CLEAN DISPLAY COLUMN
# --------------------------------------

df["display"] = (
    df["display"]
    .astype(str)
    .str.lower()
    .str.strip()
)

# --------------------------------------
# EXTRACT DISPLAY SIZE IN INCH
# --------------------------------------

df["display_size_inch"] = df["display"].str.extract(
    r'\((\d+\.?\d*)\s*inch',
    expand=False
)

df["display_size_inch"] = pd.to_numeric(
    df["display_size_inch"],
    errors="coerce"
)

# --------------------------------------
# EXTRACT RESOLUTION TYPE
# --------------------------------------

def get_resolution_type(text):

    text = str(text).lower()

    if "quad hd" in text:
        return "quad_hd"

    elif "full hd" in text:
        return "full_hd"

    elif "hd+" in text:
        return "hd_plus"

    elif "hd" in text:
        return "hd"

    elif "fwvga" in text:
        return "fwvga"

    elif "wvga" in text:
        return "wvga"

    elif "hvga" in text:
        return "hvga"

    else:
        return "unknown"


df["resolution_type"] = df["display"].apply(get_resolution_type)

# --------------------------------------
# HANDLE NULL VALUES
# --------------------------------------

df["display_size_inch"] = df["display_size_inch"].fillna(
    df["display_size_inch"].median()
)

# --------------------------------------
# FINAL OUTPUT
# --------------------------------------

print(df[[
    "display",
    "display_size_inch",
    "resolution_type"
]].head(20))
```

                                      display  display_size_inch resolution_type
    0         15.8 cm (6.22 inch) hd+ display               6.22         hd_plus
    1        16.56 cm (6.52 inch) hd+ display               6.52         hd_plus
    2        16.56 cm (6.52 inch) hd+ display               6.52         hd_plus
    3        16.56 cm (6.52 inch) hd+ display               6.52         hd_plus
    4         15.49 cm (6.1 inch) hd+ display               6.10         hd_plus
    5         15.49 cm (6.1 inch) hd+ display               6.10         hd_plus
    6         15.49 cm (6.1 inch) hd+ display               6.10         hd_plus
    7         15.49 cm (6.1 inch) hd+ display               6.10         hd_plus
    8        16.56 cm (6.52 inch) hd+ display               6.52         hd_plus
    9         15.49 cm (6.1 inch) hd+ display               6.10         hd_plus
    10        15.8 cm (6.22 inch) hd+ display               6.22         hd_plus
    11        15.8 cm (6.22 inch) hd+ display               6.22         hd_plus
    12          17.78 cm (7 inch) hd+ display               7.00         hd_plus
    13       16.56 cm (6.52 inch) hd+ display               6.52         hd_plus
    14       16.56 cm (6.52 inch) hd+ display               6.52         hd_plus
    15        15.49 cm (6.1 inch) hd+ display               6.10         hd_plus
    16   16.51 cm (6.5 inch) full hd+ display               6.50         full_hd
    17  16.94 cm (6.67 inch) full hd+ display               6.67         full_hd
    18        16.76 cm (6.6 inch) hd+ display               6.60         hd_plus
    19        16.76 cm (6.6 inch) hd+ display               6.60         hd_plus
    


```python
# ======================================
# MEMORY COLUMN FEATURE ENGINEERING
# ======================================

import pandas as pd
import numpy as np

df = df.copy()

# --------------------------------------
# CLEAN MEMORY COLUMN
# --------------------------------------

df["memory"] = (
    df["memory"]
    .astype(str)
    .str.lower()
    .str.strip()
)

# --------------------------------------
# EXTRACT RAM
# --------------------------------------

df["ram_gb"] = df["memory"].str.extract(
    r'(\d+\.?\d*)\s*gb\s*ram',
    expand=False
)

# handle MB RAM values

mb_ram_mask = df["ram_gb"].isnull()

df.loc[mb_ram_mask, "ram_gb"] = (
    df.loc[mb_ram_mask, "memory"]
    .str.extract(r'(\d+)\s*mb\s*ram', expand=False)
    .astype(float) / 1024
)

df["ram_gb"] = pd.to_numeric(
    df["ram_gb"],
    errors="coerce"
)

# --------------------------------------
# EXTRACT ROM
# --------------------------------------

df["rom_gb"] = df["memory"].str.extract(
    r'(\d+\.?\d*)\s*gb\s*rom',
    expand=False
)

# handle MB ROM values

mb_rom_mask = df["rom_gb"].isnull()

df.loc[mb_rom_mask, "rom_gb"] = (
    df.loc[mb_rom_mask, "memory"]
    .str.extract(r'(\d+)\s*mb\s*rom', expand=False)
    .astype(float) / 1024
)

df["rom_gb"] = pd.to_numeric(
    df["rom_gb"],
    errors="coerce"
)

# --------------------------------------
# EXTRACT EXPANDABLE STORAGE
# --------------------------------------

df["expandable_storage_gb"] = df["memory"].str.extract(
    r'expandable upto\s*(\d+\.?\d*)\s*(tb|gb)',
    expand=True
)[0]

unit = df["memory"].str.extract(
    r'expandable upto\s*(\d+\.?\d*)\s*(tb|gb)',
    expand=True
)[1]

df["expandable_storage_gb"] = pd.to_numeric(
    df["expandable_storage_gb"],
    errors="coerce"
)

# convert TB to GB

tb_mask = unit == "tb"

df.loc[tb_mask, "expandable_storage_gb"] = (
    df.loc[tb_mask, "expandable_storage_gb"] * 1024
)

# --------------------------------------
# HANDLE NULL VALUES
# --------------------------------------

df["expandable_storage_gb"] = (
    df["expandable_storage_gb"]
    .fillna(0)
)

```

                                                memory  ram_gb  rom_gb  \
    0    4 gb ram | 64 gb rom | expandable upto 512 gb     4.0    64.0   
    1                             4 gb ram | 64 gb rom     4.0    64.0   
    2                            4 gb ram | 128 gb rom     4.0   128.0   
    3                            4 gb ram | 128 gb rom     4.0   128.0   
    4    3 gb ram | 32 gb rom | expandable upto 256 gb     3.0    32.0   
    5    3 gb ram | 32 gb rom | expandable upto 256 gb     3.0    32.0   
    6    2 gb ram | 32 gb rom | expandable upto 256 gb     2.0    32.0   
    7    3 gb ram | 32 gb rom | expandable upto 256 gb     3.0    32.0   
    8                             4 gb ram | 64 gb rom     4.0    64.0   
    9    3 gb ram | 32 gb rom | expandable upto 256 gb     3.0    32.0   
    10   4 gb ram | 64 gb rom | expandable upto 512 gb     4.0    64.0   
    11   4 gb ram | 64 gb rom | expandable upto 512 gb     4.0    64.0   
    12   4 gb ram | 64 gb rom | expandable upto 256 gb     4.0    64.0   
    13   3 gb ram | 32 gb rom | expandable upto 256 gb     3.0    32.0   
    14   4 gb ram | 64 gb rom | expandable upto 256 gb     4.0    64.0   
    15   2 gb ram | 32 gb rom | expandable upto 256 gb     2.0    32.0   
    16   6 gb ram | 64 gb rom | expandable upto 256 gb     6.0    64.0   
    17  6 gb ram | 128 gb rom | expandable upto 512 gb     6.0   128.0   
    18   4 gb ram | 64 gb rom | expandable upto 256 gb     4.0    64.0   
    19   4 gb ram | 64 gb rom | expandable upto 256 gb     4.0    64.0   
    
        expandable_storage_gb  
    0                   512.0  
    1                     0.0  
    2                     0.0  
    3                     0.0  
    4                   256.0  
    5                   256.0  
    6                   256.0  
    7                   256.0  
    8                     0.0  
    9                   256.0  
    10                  512.0  
    11                  512.0  
    12                  256.0  
    13                  256.0  
    14                  256.0  
    15                  256.0  
    16                  256.0  
    17                  512.0  
    18                  256.0  
    19                  256.0  
    


```python
df[[
    "memory",
    "ram_gb",
    "rom_gb",
    "expandable_storage_gb"
]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>memory</th>
      <th>ram_gb</th>
      <th>rom_gb</th>
      <th>expandable_storage_gb</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4 gb ram | 64 gb rom | expandable upto 512 gb</td>
      <td>4.0</td>
      <td>64.0</td>
      <td>512.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4 gb ram | 64 gb rom</td>
      <td>4.0</td>
      <td>64.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4 gb ram | 128 gb rom</td>
      <td>4.0</td>
      <td>128.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4 gb ram | 128 gb rom</td>
      <td>4.0</td>
      <td>128.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3 gb ram | 32 gb rom | expandable upto 256 gb</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>256.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>1 gb ram | 16 gb rom | expandable upto 128 gb</td>
      <td>1.0</td>
      <td>16.0</td>
      <td>128.0</td>
    </tr>
    <tr>
      <th>980</th>
      <td>3 gb ram | 32 gb rom</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>981</th>
      <td>4 gb ram | 64 gb rom | expandable upto 256 gb</td>
      <td>4.0</td>
      <td>64.0</td>
      <td>256.0</td>
    </tr>
    <tr>
      <th>982</th>
      <td>1 gb ram | 8 gb rom | expandable upto 32 gb</td>
      <td>1.0</td>
      <td>8.0</td>
      <td>32.0</td>
    </tr>
    <tr>
      <th>983</th>
      <td>4 gb ram | 256 gb rom | expandable upto 400 gb</td>
      <td>4.0</td>
      <td>256.0</td>
      <td>400.0</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 4 columns</p>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>warranty</th>
      <th>...</th>
      <th>rear_cam_4</th>
      <th>front_camera</th>
      <th>rear_camera_count</th>
      <th>camera_type</th>
      <th>battery_capacity</th>
      <th>display_size_inch</th>
      <th>resolution_type</th>
      <th>ram_gb</th>
      <th>rom_gb</th>
      <th>expandable_storage_gb</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mah battery</td>
      <td>12mp + 2mp | 8mp front camera</td>
      <td>15.8 cm (6.22 inch) hd+ display</td>
      <td>4 gb ram | 64 gb rom | expandable upto 512 gb</td>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>9999</td>
      <td>qualcomm snapdragon 439 processor</td>
      <td>4.4</td>
      <td>55,078 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>0.0</td>
      <td>8.0</td>
      <td>2</td>
      <td>dual</td>
      <td>5000</td>
      <td>6.22</td>
      <td>hd_plus</td>
      <td>4.0</td>
      <td>64.0</td>
      <td>512.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 64 gb rom</td>
      <td>Realme 5i (Aqua Blue, 64 GB)</td>
      <td>10999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
      <td>5000</td>
      <td>6.52</td>
      <td>hd_plus</td>
      <td>4.0</td>
      <td>64.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 128 gb rom</td>
      <td>Realme 5i (Aqua Blue, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
      <td>5000</td>
      <td>6.52</td>
      <td>hd_plus</td>
      <td>4.0</td>
      <td>128.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 128 gb rom</td>
      <td>Realme 5i (Forest Green, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>4</td>
      <td>quad</td>
      <td>5000</td>
      <td>6.52</td>
      <td>hd_plus</td>
      <td>4.0</td>
      <td>128.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4000 mah battery</td>
      <td>13mp + 2mp | 5mp front camera</td>
      <td>15.49 cm (6.1 inch) hd+ display</td>
      <td>3 gb ram | 32 gb rom | expandable upto 256 gb</td>
      <td>Realme C2 (Diamond Blue, 32 GB)</td>
      <td>7499</td>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>4.4</td>
      <td>10,091 Reviews</td>
      <td>Dual Nano SIM slots and Memory Card Slot</td>
      <td>...</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>2</td>
      <td>dual</td>
      <td>4000</td>
      <td>6.10</td>
      <td>hd_plus</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>256.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 27 columns</p>
</div>




```python
df["name"] = (
    df["name"]
    .astype(str)
    .str.strip()
)

# --------------------------------------
# BRAND
# --------------------------------------

df["brand"] = df["name"].str.split().str[0]

# --------------------------------------
# COLOR
# --------------------------------------

df["color"] = df["name"].str.extract(
    r'\((.*?),'
)

# --------------------------------------
# STORAGE
# --------------------------------------

df["storage_in_name"] = df["name"].str.extract(
    r'(\d+)\s*GB'
)

df["storage_in_name"] = pd.to_numeric(
    df["storage_in_name"],
    errors="coerce"
)

# --------------------------------------
# MODEL NAME
# --------------------------------------

df["model_name"] = df["name"].str.replace(
    r'\s*\(.*\)',
    '',
    regex=True
)

# --------------------------------------
# FLAGS
# --------------------------------------

keywords = [
    "pro",
    "plus",
    "max",
    "ultra",
    "lite",
    "prime",
    "core",
    "zoom",
    "5g"
]

for word in keywords:
    df[f"is_{word}"] = (
        df["name"]
        .str.contains(word, case=False)
        .astype(int)
    )
```


```python
df[[
    "name",
    "brand",
    "color",
    "storage_in_name",
    "model_name",
    "is_pro",
    "is_plus",
    "is_max",
    "is_ultra",
    "is_5g"
]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>brand</th>
      <th>color</th>
      <th>storage_in_name</th>
      <th>model_name</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_5g</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>Redmi</td>
      <td>Ruby Red</td>
      <td>64.0</td>
      <td>Redmi 8</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Realme 5i (Aqua Blue, 64 GB)</td>
      <td>Realme</td>
      <td>Aqua Blue</td>
      <td>64.0</td>
      <td>Realme 5i</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Realme 5i (Aqua Blue, 128 GB)</td>
      <td>Realme</td>
      <td>Aqua Blue</td>
      <td>128.0</td>
      <td>Realme 5i</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Realme 5i (Forest Green, 128 GB)</td>
      <td>Realme</td>
      <td>Forest Green</td>
      <td>128.0</td>
      <td>Realme 5i</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Realme C2 (Diamond Blue, 32 GB)</td>
      <td>Realme</td>
      <td>Diamond Blue</td>
      <td>32.0</td>
      <td>Realme C2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>Gionee P5L (Gold, 16 GB)</td>
      <td>Gionee</td>
      <td>Gold</td>
      <td>16.0</td>
      <td>Gionee P5L</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>980</th>
      <td>Nextbit Robin (Ember, 32 GB)</td>
      <td>Nextbit</td>
      <td>Ember</td>
      <td>32.0</td>
      <td>Nextbit Robin</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>981</th>
      <td>Gionee A1 Plus (Mocha Gold, 64 GB)</td>
      <td>Gionee</td>
      <td>Mocha Gold</td>
      <td>64.0</td>
      <td>Gionee A1 Plus</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>982</th>
      <td>XOLO Omega 5.0 (Black, 8 GB)</td>
      <td>XOLO</td>
      <td>Black</td>
      <td>8.0</td>
      <td>XOLO Omega 5.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>983</th>
      <td>Samsung Galaxy S9 (Midnight Black, 256 GB)</td>
      <td>Samsung</td>
      <td>Midnight Black</td>
      <td>256.0</td>
      <td>Samsung Galaxy S9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 10 columns</p>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>warranty</th>
      <th>...</th>
      <th>model_name</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mah battery</td>
      <td>12mp + 2mp | 8mp front camera</td>
      <td>15.8 cm (6.22 inch) hd+ display</td>
      <td>4 gb ram | 64 gb rom | expandable upto 512 gb</td>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>9999</td>
      <td>qualcomm snapdragon 439 processor</td>
      <td>4.4</td>
      <td>55,078 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>Redmi 8</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 64 gb rom</td>
      <td>Realme 5i (Aqua Blue, 64 GB)</td>
      <td>10999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>Realme 5i</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 128 gb rom</td>
      <td>Realme 5i (Aqua Blue, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>Realme 5i</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 128 gb rom</td>
      <td>Realme 5i (Forest Green, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20,062 Reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>Realme 5i</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4000 mah battery</td>
      <td>13mp + 2mp | 5mp front camera</td>
      <td>15.49 cm (6.1 inch) hd+ display</td>
      <td>3 gb ram | 32 gb rom | expandable upto 256 gb</td>
      <td>Realme C2 (Diamond Blue, 32 GB)</td>
      <td>7499</td>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>4.4</td>
      <td>10,091 Reviews</td>
      <td>Dual Nano SIM slots and Memory Card Slot</td>
      <td>...</td>
      <td>Realme C2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>2300 mah li-ion polymer battery</td>
      <td>8mp rear camera | 5mp front camera</td>
      <td>12.7 cm (5 inch) hd display</td>
      <td>1 gb ram | 16 gb rom | expandable upto 128 gb</td>
      <td>Gionee P5L (Gold, 16 GB)</td>
      <td>4290</td>
      <td>quad core 1.3ghz processor</td>
      <td>3.7</td>
      <td>201 Reviews</td>
      <td>Brand Warranty of 1 Year</td>
      <td>...</td>
      <td>Gionee P5L</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>980</th>
      <td>2680 mah li-ion battery</td>
      <td>13mp rear camera | 5mp front camera</td>
      <td>13.21 cm (5.2 inch) full hd display</td>
      <td>3 gb ram | 32 gb rom</td>
      <td>Nextbit Robin (Ember, 32 GB)</td>
      <td>19999</td>
      <td>qualcomm snapdragon 808 msm8992 processor</td>
      <td>4.0</td>
      <td>516 Reviews</td>
      <td>Brand Warranty of 1 Year</td>
      <td>...</td>
      <td>Nextbit Robin</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>981</th>
      <td>4550 mah battery</td>
      <td>13mp + 5mp | 20mp front camera</td>
      <td>15.24 cm (6 inch) full hd display</td>
      <td>4 gb ram | 64 gb rom | expandable upto 256 gb</td>
      <td>Gionee A1 Plus (Mocha Gold, 64 GB)</td>
      <td>10499</td>
      <td>helio p25 mt 6757cd processor</td>
      <td>4.1</td>
      <td>710 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>Gionee A1 Plus</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>982</th>
      <td>2100 mah li-ion battery</td>
      <td>8mp rear camera | 2mp front camera</td>
      <td>12.7 cm (5 inch) hd display</td>
      <td>1 gb ram | 8 gb rom | expandable upto 32 gb</td>
      <td>XOLO Omega 5.0 (Black, 8 GB)</td>
      <td>8990</td>
      <td>mtk 6592m processor</td>
      <td>3.8</td>
      <td>81 Reviews</td>
      <td>1 Year Manufacturer Warranty</td>
      <td>...</td>
      <td>XOLO Omega 5.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>983</th>
      <td>3000 mah battery</td>
      <td>12mp rear camera | 8mp front camera</td>
      <td>14.73 cm (5.8 inch) quad hd+ display</td>
      <td>4 gb ram | 256 gb rom | expandable upto 400 gb</td>
      <td>Samsung Galaxy S9 (Midnight Black, 256 GB)</td>
      <td>65900</td>
      <td>exynos 9810 processor</td>
      <td>4.4</td>
      <td>2,331 Reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>Samsung Galaxy S9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 40 columns</p>
</div>




```python
df["reviews"] = (
    df["reviews"]
    .astype(str)
    .str.lower()
    .str.replace(",", "", regex=False)
    .str.strip()
)

# --------------------------------------
# EXTRACT NUMERIC VALUES
# --------------------------------------

df["review_count"] = df["reviews"].str.extract(
    r'(\d+)',
    expand=False
)

# --------------------------------------
# CONVERT TO NUMERIC
# --------------------------------------

df["review_count"] = pd.to_numeric(
    df["review_count"],
    errors="coerce"
)

# --------------------------------------
# HANDLE NULL VALUES
# --------------------------------------

df["review_count"] = df["review_count"].fillna(0)

# --------------------------------------
# FINAL OUTPUT
# --------------------------------------

print(df[[
    "reviews",
    "review_count"
]].head(20))
```

              reviews  review_count
    0   55078 reviews       55078.0
    1   20062 reviews       20062.0
    2   20062 reviews       20062.0
    3   20062 reviews       20062.0
    4   10091 reviews       10091.0
    5   10091 reviews       10091.0
    6   67674 reviews       67674.0
    7   10091 reviews       10091.0
    8   20062 reviews       20062.0
    9   10091 reviews       10091.0
    10  55078 reviews       55078.0
    11  55078 reviews       55078.0
    12   2358 reviews        2358.0
    13   5641 reviews        5641.0
    14   8877 reviews        8877.0
    15  67674 reviews       67674.0
    16   4318 reviews        4318.0
    17  17578 reviews       17578.0
    18   2263 reviews        2263.0
    19   2263 reviews        2263.0
    


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>warranty</th>
      <th>...</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
      <th>review_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5000 mah battery</td>
      <td>12mp + 2mp | 8mp front camera</td>
      <td>15.8 cm (6.22 inch) hd+ display</td>
      <td>4 gb ram | 64 gb rom | expandable upto 512 gb</td>
      <td>Redmi 8 (Ruby Red, 64 GB)</td>
      <td>9999</td>
      <td>qualcomm snapdragon 439 processor</td>
      <td>4.4</td>
      <td>55078 reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>55078.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 64 gb rom</td>
      <td>Realme 5i (Aqua Blue, 64 GB)</td>
      <td>10999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20062 reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 128 gb rom</td>
      <td>Realme 5i (Aqua Blue, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20062 reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5000 mah battery</td>
      <td>12mp + 8mp + 2mp + 2mp | 8mp front camera</td>
      <td>16.56 cm (6.52 inch) hd+ display</td>
      <td>4 gb ram | 128 gb rom</td>
      <td>Realme 5i (Forest Green, 128 GB)</td>
      <td>11999</td>
      <td>qualcomm snapdragon 665 2 ghz processor</td>
      <td>4.5</td>
      <td>20062 reviews</td>
      <td>Sunrise Design</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4000 mah battery</td>
      <td>13mp + 2mp | 5mp front camera</td>
      <td>15.49 cm (6.1 inch) hd+ display</td>
      <td>3 gb ram | 32 gb rom | expandable upto 256 gb</td>
      <td>Realme C2 (Diamond Blue, 32 GB)</td>
      <td>7499</td>
      <td>mediatek p22 octa core 2.0 ghz processor</td>
      <td>4.4</td>
      <td>10091 reviews</td>
      <td>Dual Nano SIM slots and Memory Card Slot</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10091.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>2300 mah li-ion polymer battery</td>
      <td>8mp rear camera | 5mp front camera</td>
      <td>12.7 cm (5 inch) hd display</td>
      <td>1 gb ram | 16 gb rom | expandable upto 128 gb</td>
      <td>Gionee P5L (Gold, 16 GB)</td>
      <td>4290</td>
      <td>quad core 1.3ghz processor</td>
      <td>3.7</td>
      <td>201 reviews</td>
      <td>Brand Warranty of 1 Year</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>201.0</td>
    </tr>
    <tr>
      <th>980</th>
      <td>2680 mah li-ion battery</td>
      <td>13mp rear camera | 5mp front camera</td>
      <td>13.21 cm (5.2 inch) full hd display</td>
      <td>3 gb ram | 32 gb rom</td>
      <td>Nextbit Robin (Ember, 32 GB)</td>
      <td>19999</td>
      <td>qualcomm snapdragon 808 msm8992 processor</td>
      <td>4.0</td>
      <td>516 reviews</td>
      <td>Brand Warranty of 1 Year</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>516.0</td>
    </tr>
    <tr>
      <th>981</th>
      <td>4550 mah battery</td>
      <td>13mp + 5mp | 20mp front camera</td>
      <td>15.24 cm (6 inch) full hd display</td>
      <td>4 gb ram | 64 gb rom | expandable upto 256 gb</td>
      <td>Gionee A1 Plus (Mocha Gold, 64 GB)</td>
      <td>10499</td>
      <td>helio p25 mt 6757cd processor</td>
      <td>4.1</td>
      <td>710 reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>710.0</td>
    </tr>
    <tr>
      <th>982</th>
      <td>2100 mah li-ion battery</td>
      <td>8mp rear camera | 2mp front camera</td>
      <td>12.7 cm (5 inch) hd display</td>
      <td>1 gb ram | 8 gb rom | expandable upto 32 gb</td>
      <td>XOLO Omega 5.0 (Black, 8 GB)</td>
      <td>8990</td>
      <td>mtk 6592m processor</td>
      <td>3.8</td>
      <td>81 reviews</td>
      <td>1 Year Manufacturer Warranty</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>81.0</td>
    </tr>
    <tr>
      <th>983</th>
      <td>3000 mah battery</td>
      <td>12mp rear camera | 8mp front camera</td>
      <td>14.73 cm (5.8 inch) quad hd+ display</td>
      <td>4 gb ram | 256 gb rom | expandable upto 400 gb</td>
      <td>Samsung Galaxy S9 (Midnight Black, 256 GB)</td>
      <td>65900</td>
      <td>exynos 9810 processor</td>
      <td>4.4</td>
      <td>2331 reviews</td>
      <td>Brand Warranty of 1 Year Available for Mobile ...</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2331.0</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 41 columns</p>
</div>




```python
df.dtypes
```




    battery                   object
    camera                    object
    display                   object
    memory                    object
    name                      object
    price                      int64
    processor                 object
    rating                   float64
    reviews                   object
    warranty                  object
    processor_brand           object
    processor_series          object
    processor_type            object
    core_type                 object
    rear_cam_1               float64
    rear_cam_2               float64
    rear_cam_3               float64
    rear_cam_4               float64
    front_camera             float64
    rear_camera_count          int64
    camera_type               object
    battery_capacity           int64
    display_size_inch        float64
    resolution_type           object
    ram_gb                   float64
    rom_gb                   float64
    expandable_storage_gb    float64
    brand                     object
    color                     object
    storage_in_name          float64
    model_name                object
    is_pro                     int32
    is_plus                    int32
    is_max                     int32
    is_ultra                   int32
    is_lite                    int32
    is_prime                   int32
    is_core                    int32
    is_zoom                    int32
    is_5g                      int32
    review_count             float64
    dtype: object




```python
df[["processor_brand","processor_series","processor_type"]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>processor_brand</th>
      <th>processor_series</th>
      <th>processor_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>1</th>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>2</th>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>3</th>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>other</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>980</th>
      <td>snapdragon</td>
      <td>800</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>981</th>
      <td>mediatek</td>
      <td>p25</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>982</th>
      <td>mediatek</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>983</th>
      <td>exynos</td>
      <td>9000</td>
      <td>normal</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 3 columns</p>
</div>




```python
df.drop(columns=["warranty"], inplace=True)
```

### Validation or comparing 


```python
df[[
    "display",
    "display_size_inch",
    "resolution_type"
]].sample(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>display</th>
      <th>display_size_inch</th>
      <th>resolution_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>738</th>
      <td>16.0 cm (6.3 inch) full hd+ display</td>
      <td>6.30</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>68</th>
      <td>15.8 cm (6.22 inch) full hd+ display</td>
      <td>6.22</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>890</th>
      <td>12.7 cm (5 inch) hd display</td>
      <td>5.00</td>
      <td>hd</td>
    </tr>
    <tr>
      <th>89</th>
      <td>15.8 cm (6.22 inch) hd+ display</td>
      <td>6.22</td>
      <td>hd_plus</td>
    </tr>
    <tr>
      <th>219</th>
      <td>16.59 cm (6.53 inch) full hd+ display</td>
      <td>6.53</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>407</th>
      <td>15.9 cm (6.26 inch) hd+ display</td>
      <td>6.26</td>
      <td>hd_plus</td>
    </tr>
    <tr>
      <th>403</th>
      <td>16.59 cm (6.53 inch) display</td>
      <td>6.53</td>
      <td>unknown</td>
    </tr>
    <tr>
      <th>790</th>
      <td>16.0 cm (6.3 inch) full hd+ display</td>
      <td>6.30</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>771</th>
      <td>12.7 cm (5 inch) hd display</td>
      <td>5.00</td>
      <td>hd</td>
    </tr>
    <tr>
      <th>145</th>
      <td>16.59 cm (6.53 inch) full hd+ display</td>
      <td>6.53</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>906</th>
      <td>13.21 cm (5.2 inch) full hd display</td>
      <td>5.20</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>851</th>
      <td>13.84 cm (5.45 inch) hd+ display</td>
      <td>5.45</td>
      <td>hd_plus</td>
    </tr>
    <tr>
      <th>216</th>
      <td>16.59 cm (6.53 inch) full hd+ display</td>
      <td>6.53</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>978</th>
      <td>12.7 cm (5 inch) hd display</td>
      <td>5.00</td>
      <td>hd</td>
    </tr>
    <tr>
      <th>793</th>
      <td>13.21 cm (5.2 inch) hd display</td>
      <td>5.20</td>
      <td>hd</td>
    </tr>
    <tr>
      <th>824</th>
      <td>15.21 cm (5.99 inch) full hd+ display</td>
      <td>5.99</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>51</th>
      <td>16.0 cm (6.3 inch) full hd+ display</td>
      <td>6.30</td>
      <td>full_hd</td>
    </tr>
    <tr>
      <th>399</th>
      <td>15.8 cm (6.22 inch) hd+ display</td>
      <td>6.22</td>
      <td>hd_plus</td>
    </tr>
    <tr>
      <th>416</th>
      <td>16.26 cm (6.4 inch) hd+ display</td>
      <td>6.40</td>
      <td>hd_plus</td>
    </tr>
    <tr>
      <th>159</th>
      <td>16.26 cm (6.4 inch) full hd+ display</td>
      <td>6.40</td>
      <td>full_hd</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[[
    "processor",
    "processor_brand",
    "processor_series",
    "processor_type"
]].sample(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>processor</th>
      <th>processor_brand</th>
      <th>processor_series</th>
      <th>processor_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>773</th>
      <td>qualcomm snapdragon quad core processor</td>
      <td>snapdragon</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>891</th>
      <td>spreadtrum sc9832 quad core 1.3ghz processor</td>
      <td>spreadtrum</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>556</th>
      <td>qualcomm snapdragon 675 aie processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>657</th>
      <td>qualcomm snapdragon 660 aie processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>395</th>
      <td>cortex a53 architecture quad core processor</td>
      <td>other</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>880</th>
      <td>qualcomm snapdragon 410 quad core 1.2ghz proce...</td>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>121</th>
      <td>qualcomm snapdragon 665 aie processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>841</th>
      <td>qualcomm snapdragon 632 octa core processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>66</th>
      <td>mediatek helio p35 mt6765vcb 4 x cortexa53l  4...</td>
      <td>mediatek</td>
      <td>p35</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>35</th>
      <td>mtk helio p22 processor</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>757</th>
      <td>mediatek helio a22 processor</td>
      <td>mediatek</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>563</th>
      <td>mt8735a a53 processor</td>
      <td>other</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>390</th>
      <td>exynos 9610 processor</td>
      <td>exynos</td>
      <td>9000</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>93</th>
      <td>helio g70 processor</td>
      <td>mediatek</td>
      <td>g70</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>801</th>
      <td>qualcomm snapdragon 632 octa core processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>63</th>
      <td>qualcomm snapdragon 730g processor</td>
      <td>snapdragon</td>
      <td>700</td>
      <td>gaming</td>
    </tr>
    <tr>
      <th>298</th>
      <td>qualcomm 712 processor</td>
      <td>snapdragon</td>
      <td>unknown</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>973</th>
      <td>qualcomm snapdragon 670 processor</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>521</th>
      <td>qualcomm snapdragon 730 processor</td>
      <td>snapdragon</td>
      <td>700</td>
      <td>normal</td>
    </tr>
    <tr>
      <th>517</th>
      <td>qualcomm snapdragon 865 processor</td>
      <td>snapdragon</td>
      <td>800</td>
      <td>gaming</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[[
    "battery",
    "battery_capacity"
]].sample(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>battery_capacity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>517</th>
      <td>4300 mah battery</td>
      <td>4300</td>
    </tr>
    <tr>
      <th>230</th>
      <td>5020 mah battery</td>
      <td>5020</td>
    </tr>
    <tr>
      <th>748</th>
      <td>4000 mah li-polymer battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>193</th>
      <td>5000 mah battery</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>201</th>
      <td>4000 mah battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>378</th>
      <td>4200 mah lithium-ion battery</td>
      <td>4200</td>
    </tr>
    <tr>
      <th>708</th>
      <td>3070 mah battery</td>
      <td>3070</td>
    </tr>
    <tr>
      <th>769</th>
      <td>2500 mah lithium polymer battery</td>
      <td>2500</td>
    </tr>
    <tr>
      <th>18</th>
      <td>5000 mah li-ion polymer battery</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>531</th>
      <td>4000 mah lithium ion battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>115</th>
      <td>4000 mah li-ion polymer battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>980</th>
      <td>2680 mah li-ion battery</td>
      <td>2680</td>
    </tr>
    <tr>
      <th>270</th>
      <td>4000 mah battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>35</th>
      <td>4030 mah li-ion battery</td>
      <td>4030</td>
    </tr>
    <tr>
      <th>543</th>
      <td>4230 mah battery</td>
      <td>4230</td>
    </tr>
    <tr>
      <th>328</th>
      <td>4000 mah battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>627</th>
      <td>4000 mah li-polymer battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>877</th>
      <td>2000 mah battery</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>134</th>
      <td>4000 mah lithium-ion battery</td>
      <td>4000</td>
    </tr>
    <tr>
      <th>103</th>
      <td>4300 mah battery</td>
      <td>4300</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[[
    "name",
    "brand",
    "model_name",
    "is_pro",
    "is_5g"
]].sample(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>brand</th>
      <th>model_name</th>
      <th>is_pro</th>
      <th>is_5g</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>690</th>
      <td>MI3 (Metallic Grey, 16 GB)</td>
      <td>MI3</td>
      <td>MI3</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>735</th>
      <td>Lava P7+ (Grey, 8 GB)</td>
      <td>Lava</td>
      <td>Lava P7+</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>581</th>
      <td>Infinix Hot S3X (Milan Black, 32 GB)</td>
      <td>Infinix</td>
      <td>Infinix Hot S3X</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>955</th>
      <td>XOLO ZX (Midnight Blue, 64 GB)</td>
      <td>XOLO</td>
      <td>XOLO ZX</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>180</th>
      <td>Samsung Galaxy M11 (Black, 32 GB)</td>
      <td>Samsung</td>
      <td>Samsung Galaxy M11</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>101</th>
      <td>OPPO A9 2020 (Vanilla Mint, 128 GB)</td>
      <td>OPPO</td>
      <td>OPPO A9 2020</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>112</th>
      <td>OPPO A5s (Black, 64 GB)</td>
      <td>OPPO</td>
      <td>OPPO A5s</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>922</th>
      <td>Honor 10 Lite (Midnight Black, 64 GB)</td>
      <td>Honor</td>
      <td>Honor 10 Lite</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>308</th>
      <td>Asus ROG Phone II (Black, 128 GB)</td>
      <td>Asus</td>
      <td>Asus ROG Phone II</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>571</th>
      <td>Mobiistar C1 (Gold, 16 GB)</td>
      <td>Mobiistar</td>
      <td>Mobiistar C1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>256</th>
      <td>Samsung Galaxy M21 (Midnight Blue, 64 GB)</td>
      <td>Samsung</td>
      <td>Samsung Galaxy M21</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>469</th>
      <td>Asus Zenfone Max Pro M1 (Black, 64 GB)</td>
      <td>Asus</td>
      <td>Asus Zenfone Max Pro M1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>156</th>
      <td>OPPO A9 2020 (Marine Green, 128 GB)</td>
      <td>OPPO</td>
      <td>OPPO A9 2020</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>220</th>
      <td>Redmi Note 8 Pro (Halo White, 64 GB)</td>
      <td>Redmi</td>
      <td>Redmi Note 8 Pro</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>262</th>
      <td>Samsung Galaxy M31 (Ocean Blue, 64 GB)</td>
      <td>Samsung</td>
      <td>Samsung Galaxy M31</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>489</th>
      <td>Gionee P7 Max (Gold, 32 GB)</td>
      <td>Gionee</td>
      <td>Gionee P7 Max</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>881</th>
      <td>OPPO F5 Youth (Gold, 32 GB)</td>
      <td>OPPO</td>
      <td>OPPO F5 Youth</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>425</th>
      <td>LG W30 (Aurora Green, 32 GB)</td>
      <td>LG</td>
      <td>LG W30</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>415</th>
      <td>Honor 20 (Sapphire Blue, 128 GB)</td>
      <td>Honor</td>
      <td>Honor 20</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>538</th>
      <td>Mi A2 (Gold, 128 GB)</td>
      <td>Mi</td>
      <td>Mi A2</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[[
    "rear_cam_1",
    "ram_gb",
    "rom_gb",
    "battery_capacity",
    "display_size_inch","front_camera"
]].isnull().sum()
```




    rear_cam_1            0
    ram_gb                0
    rom_gb                0
    battery_capacity      0
    display_size_inch     0
    front_camera         24
    dtype: int64




```python
df[["camera","front_camera","name"]][df["front_camera"].isnull()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>camera</th>
      <th>front_camera</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>116</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Aqua Green, 64 GB)</td>
    </tr>
    <tr>
      <th>117</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Pebble Grey, 64 GB)</td>
    </tr>
    <tr>
      <th>132</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Pebble Grey, 128 GB)</td>
    </tr>
    <tr>
      <th>133</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Aqua Green, 128 GB)</td>
    </tr>
    <tr>
      <th>230</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Arctic White, 64 GB)</td>
    </tr>
    <tr>
      <th>295</th>
      <td>48mp + 2mp + 16mp</td>
      <td>NaN</td>
      <td>OnePlus 8 (Glacial Green, 256 GB)</td>
    </tr>
    <tr>
      <th>473</th>
      <td>2mp rear camera</td>
      <td>NaN</td>
      <td>Karbonn A52 plus (White and Silver, 4 GB)</td>
    </tr>
    <tr>
      <th>482</th>
      <td>5mp rear camera</td>
      <td>NaN</td>
      <td>Kenxinda P8 (Gold, 8 GB)</td>
    </tr>
    <tr>
      <th>486</th>
      <td>13mp rear camera</td>
      <td>NaN</td>
      <td>Nokia 3.1 Plus (Charcoal, 32 GB)</td>
    </tr>
    <tr>
      <th>571</th>
      <td>5mp rear camera</td>
      <td>NaN</td>
      <td>Mobiistar C1 (Gold, 16 GB)</td>
    </tr>
    <tr>
      <th>573</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Vivo V17 (Admiral Blue, 128 GB)</td>
    </tr>
    <tr>
      <th>578</th>
      <td>13mp rear camera</td>
      <td>NaN</td>
      <td>Forme R7 (Champagne Gold, 16 GB)</td>
    </tr>
    <tr>
      <th>612</th>
      <td>2mp rear camera</td>
      <td>NaN</td>
      <td>Karbonn A52 plus (Black and Gold, 4 GB)</td>
    </tr>
    <tr>
      <th>647</th>
      <td>16mp rear camera</td>
      <td>NaN</td>
      <td>Nokia 6.1 (Iron, White, 32 GB)</td>
    </tr>
    <tr>
      <th>664</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Pebble Grey, 128 GB)</td>
    </tr>
    <tr>
      <th>665</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Arctic White, 128 GB)</td>
    </tr>
    <tr>
      <th>666</th>
      <td>48mp rear camera</td>
      <td>NaN</td>
      <td>Redmi Note 9 (Aqua Green, 128 GB)</td>
    </tr>
    <tr>
      <th>714</th>
      <td>13mp rear camera</td>
      <td>NaN</td>
      <td>Redmi 6A (Black, 32 GB)</td>
    </tr>
    <tr>
      <th>753</th>
      <td>13mp + 5mp + 5mp</td>
      <td>NaN</td>
      <td>Gome C7 Note (Gold, 32 GB)</td>
    </tr>
    <tr>
      <th>760</th>
      <td>13mp rear camera</td>
      <td>NaN</td>
      <td>Forme R7 (Red&amp;Black, 16 GB)</td>
    </tr>
    <tr>
      <th>764</th>
      <td>16mp rear camera</td>
      <td>NaN</td>
      <td>Nokia 6.1 (Gold, Blue, 32 GB)</td>
    </tr>
    <tr>
      <th>825</th>
      <td>16mp rear camera</td>
      <td>NaN</td>
      <td>Vivo U20 (Racing Black, 64 GB)</td>
    </tr>
    <tr>
      <th>833</th>
      <td>13mp rear camera</td>
      <td>NaN</td>
      <td>Redmi 6A (Blue, 32 GB)</td>
    </tr>
    <tr>
      <th>964</th>
      <td>13mp rear camera</td>
      <td>NaN</td>
      <td>Redmi 6A (Gold, 32 GB)</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[df["ram_gb"] > 32]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>processor_brand</th>
      <th>...</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
      <th>review_count</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 40 columns</p>
</div>




```python
df[df["display_size_inch"] > 10]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>processor_brand</th>
      <th>...</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
      <th>review_count</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 40 columns</p>
</div>




```python
df[df["battery_capacity"] < 500]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>battery</th>
      <th>camera</th>
      <th>display</th>
      <th>memory</th>
      <th>name</th>
      <th>price</th>
      <th>processor</th>
      <th>rating</th>
      <th>reviews</th>
      <th>processor_brand</th>
      <th>...</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
      <th>review_count</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 40 columns</p>
</div>




```python
df.dtypes
```




    battery                   object
    camera                    object
    display                   object
    memory                    object
    name                      object
    price                      int64
    processor                 object
    rating                   float64
    reviews                   object
    processor_brand           object
    processor_series          object
    processor_type            object
    core_type                 object
    rear_cam_1               float64
    rear_cam_2               float64
    rear_cam_3               float64
    rear_cam_4               float64
    front_camera             float64
    rear_camera_count          int64
    camera_type               object
    battery_capacity           int64
    display_size_inch        float64
    resolution_type           object
    ram_gb                   float64
    rom_gb                   float64
    expandable_storage_gb    float64
    brand                     object
    color                     object
    storage_in_name          float64
    model_name                object
    is_pro                     int32
    is_plus                    int32
    is_max                     int32
    is_ultra                   int32
    is_lite                    int32
    is_prime                   int32
    is_core                    int32
    is_zoom                    int32
    is_5g                      int32
    review_count             float64
    dtype: object



-------

### New column and data set 


```python
# ==========================================
# REMOVE OLD RAW COLUMNS
# ==========================================

old_columns = [
    "battery",
    "camera",
    "display",
    "memory",
    "name",
    "processor",
    "reviews"
]

df_new = df.drop(columns=old_columns)

# ==========================================
# NUMERICAL COLUMNS
# ==========================================

num_col = df_new.select_dtypes(
    include=["int64", "float64", "int32"]
).columns.tolist()

print("NUMERICAL COLUMNS:\n")
print(num_col)

# ==========================================
# CATEGORICAL COLUMNS
# ==========================================

cat_col = df_new.select_dtypes(
    include=["object"]
).columns.tolist()

print("\nCATEGORICAL COLUMNS:\n")
print(cat_col)
```

    NUMERICAL COLUMNS:
    
    ['price', 'rating', 'rear_cam_1', 'rear_cam_2', 'rear_cam_3', 'rear_cam_4', 'front_camera', 'rear_camera_count', 'battery_capacity', 'display_size_inch', 'ram_gb', 'rom_gb', 'expandable_storage_gb', 'storage_in_name', 'is_pro', 'is_plus', 'is_max', 'is_ultra', 'is_lite', 'is_prime', 'is_core', 'is_zoom', 'is_5g', 'review_count']
    
    CATEGORICAL COLUMNS:
    
    ['processor_brand', 'processor_series', 'processor_type', 'core_type', 'camera_type', 'resolution_type', 'brand', 'color', 'model_name']
    


```python
cat_col = df_new.select_dtypes(
    include=["object"]
)

num_cols = df_new.select_dtypes(
    include=["int64", "float64", "int32"]
)
num_col
```




    ['price',
     'rating',
     'rear_cam_1',
     'rear_cam_2',
     'rear_cam_3',
     'rear_cam_4',
     'front_camera',
     'rear_camera_count',
     'battery_capacity',
     'display_size_inch',
     'ram_gb',
     'rom_gb',
     'expandable_storage_gb',
     'storage_in_name',
     'is_pro',
     'is_plus',
     'is_max',
     'is_ultra',
     'is_lite',
     'is_prime',
     'is_core',
     'is_zoom',
     'is_5g',
     'review_count']




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 838 entries, 0 to 983
    Data columns (total 40 columns):
     #   Column                 Non-Null Count  Dtype  
    ---  ------                 --------------  -----  
     0   battery                838 non-null    object 
     1   camera                 838 non-null    object 
     2   display                838 non-null    object 
     3   memory                 838 non-null    object 
     4   name                   838 non-null    object 
     5   price                  838 non-null    int64  
     6   processor              838 non-null    object 
     7   rating                 830 non-null    float64
     8   reviews                838 non-null    object 
     9   processor_brand        838 non-null    object 
     10  processor_series       838 non-null    object 
     11  processor_type         838 non-null    object 
     12  core_type              838 non-null    object 
     13  rear_cam_1             838 non-null    float64
     14  rear_cam_2             838 non-null    float64
     15  rear_cam_3             838 non-null    float64
     16  rear_cam_4             838 non-null    float64
     17  front_camera           814 non-null    float64
     18  rear_camera_count      838 non-null    int64  
     19  camera_type            838 non-null    object 
     20  battery_capacity       838 non-null    int64  
     21  display_size_inch      838 non-null    float64
     22  resolution_type        838 non-null    object 
     23  ram_gb                 838 non-null    float64
     24  rom_gb                 838 non-null    float64
     25  expandable_storage_gb  838 non-null    float64
     26  brand                  838 non-null    object 
     27  color                  838 non-null    object 
     28  storage_in_name        836 non-null    float64
     29  model_name             838 non-null    object 
     30  is_pro                 838 non-null    int32  
     31  is_plus                838 non-null    int32  
     32  is_max                 838 non-null    int32  
     33  is_ultra               838 non-null    int32  
     34  is_lite                838 non-null    int32  
     35  is_prime               838 non-null    int32  
     36  is_core                838 non-null    int32  
     37  is_zoom                838 non-null    int32  
     38  is_5g                  838 non-null    int32  
     39  review_count           838 non-null    float64
    dtypes: float64(12), int32(9), int64(3), object(16)
    memory usage: 239.0+ KB
    


```python
df_new.isnull().sum()
```




    price                     0
    rating                    8
    processor_brand           0
    processor_series          0
    processor_type            0
    core_type                 0
    rear_cam_1                0
    rear_cam_2                0
    rear_cam_3                0
    rear_cam_4                0
    front_camera             24
    rear_camera_count         0
    camera_type               0
    battery_capacity          0
    display_size_inch         0
    resolution_type           0
    ram_gb                    0
    rom_gb                    0
    expandable_storage_gb     0
    brand                     0
    color                     0
    storage_in_name           2
    model_name                0
    is_pro                    0
    is_plus                   0
    is_max                    0
    is_ultra                  0
    is_lite                   0
    is_prime                  0
    is_core                   0
    is_zoom                   0
    is_5g                     0
    review_count              0
    dtype: int64




```python
def irregularities(data):
    for i in data:
        print('*'*20, i, '*'*20)
        print(data[i].unique())
        print()

irregularities(df_new)
```

    ******************** price ********************
    [  9999  10999  11999   7499   6999   8999  15999  18499   9499  14999
      12999  12990  17499   7999  13999   9990   7880  10990  17999   9890
      16999  10499  17990  16990  18990  24999  20999  12490   9899   8345
      22999  14990  11490  18999  11499  21499  14498  27990  34990   8299
      19790  15864  15891   9488   8990  21990  25999   9590   7990   8400
      13859  19990  37990  21889  16989  35999  19948  33333  24990   8890
       8898  13984  14598  11970  16984   8450  23999  17987  17986   9390
      31999  32999  19999  15990   7777  49999   5777  21999  34834  37100
      36999   8290   7844  12987  18934  29990  29999  18918  38899  41990
      49990  11990   6299  36599  15798  42999   6385  13885  12399   9588
      27999  44990   6499  13760  39999   8499  17495  16998  30999  11000
       8440   8090   8369  37999  16899  18099  16985  17998  45470   7290
      15490   6394  47999   9476  14082   9929  33999  29499  15499   4990
       4999  13990   8252  54990   6498   5999  19900   6989   8399  25990
      23970  77999  41999 104999   5050  10599   3790   3750   3999   2741
      10285   3199  31590   8980   7088   3690  10390   7980   6789  28000
      11350   8190  44999  60990  27490  18570  26990  12900  59000   6990
      57800  65200   2850   8250  21099  12199   6490  14900   7150   7490
       3990  23990  38990   8799  26999  36000   9599   5290  77899   4499
       5990   3290   6699   5549   3666   5749   9490   8600   5299  16490
       5950  18900   5499   5699  39000   3499  18000  13750   7500  17498
      17198  13499  12950  26900   7339  16995  24600   6155   9188   2999
       5599  39900  36990  14290  11599   2499   3550   3599  97999  63400
      26499   4761   6799   4199   5124  14399   4799   7450  42021   5498
       4099  11200   6190   3749  11998   6450   7399  16399  34999   6800
       3449  10090   8192   4399   9005  22221  13980   5799   5896   8979
      10250   4889  10465   6379  59990  54999  11980   5280   7890   1999
       9199  11199  17989   5742  16499  20990   4290  65900]
    
    ******************** rating ********************
    [4.4 4.5 4.3 4.2 4.7 4.6 4.1 4.8 3.8 4.  3.9 nan 3.7 3.6 3.4 3.2 3.5 2.7]
    
    ******************** processor_brand ********************
    ['snapdragon' 'mediatek' 'other' 'exynos' 'kirin' 'unisoc' 'spreadtrum']
    
    ******************** processor_series ********************
    ['400' '600' 'p22' 'g70' 'g90' '700' 'unknown' 'p70' '800' 'p35' 'g85'
     'p65' '9000' 'p95' 'p23' 'p60' '8000' '7000' 'p90' 'p10' '200' 'p25'
     'p15' '3000' 'p20']
    
    ******************** processor_type ********************
    ['normal' 'gaming']
    
    ******************** core_type ********************
    ['unknown' 'octa' 'quad']
    
    ******************** rear_cam_1 ********************
    [ 12.   13.   16.   64.   48.    8.   20.  108.   24.   25.    2.    5.
      12.2]
    
    ******************** rear_cam_2 ********************
    [ 2.  8.  5.  0. 12. 13. 20. 16. 48.]
    
    ******************** rear_cam_3 ********************
    [ 0.  2.  5.  8. 13. 16. 12. 10.]
    
    ******************** rear_cam_4 ********************
    [0. 2. 5. 8.]
    
    ******************** front_camera ********************
    [ 8.   5.  16.  20.  32.  13.   nan 48.  24.  44.  25.   0.3 10.   2.
     12.  40.   2.1]
    
    ******************** rear_camera_count ********************
    [2 4 3 1]
    
    ******************** camera_type ********************
    ['dual' 'quad' 'triple' 'single']
    
    ******************** battery_capacity ********************
    [5000 4000 6000 4300 4500 4230 4030 4035 4200 5020 4440 3700 3765 3950
     3100 3800 3000 4025 4065 4315 3080 2600 4020 3010 3500 4780 3600 4085
     4010 3750 4100 3340 2050 4050 3030 2300 3300 3020 1300 4045 2670 2500
     2900 3730 3060 3225 3400 2000 3050 2630 2070 3380 2400 4120 1550 2200
     3360 3070 1750 3200 1400 1800 3550 2800 3260 3180 3760 1950 4900 2350
     3130 2920 2730 4510 4550 2680 2100]
    
    ******************** display_size_inch ********************
    [6.22  6.52  6.1   7.    6.5   6.67  6.6   6.82  6.2   6.35  6.3   6.53
     6.38  6.57  6.4   6.47  6.44  6.39  5.7   6.55  6.7   6.59  6.08  5.45
     6.26  6.56  5.3   5.99  5.    6.18  5.93  6.41  5.8   6.088 6.15  6.9
     5.2   5.9   3.5   6.    5.5   5.6   5.84  6.21  5.65  5.34  5.71  4.5
     4.    6.19  6.28  6.09  6.23  6.78 ]
    
    ******************** resolution_type ********************
    ['hd_plus' 'full_hd' 'unknown' 'hd' 'fwvga' 'quad_hd' 'hvga' 'wvga']
    
    ******************** ram_gb ********************
    [ 4.    3.    2.    6.    8.   12.    1.    0.5   1.5   0.25]
    
    ******************** rom_gb ********************
    [6.40e+01 1.28e+02 3.20e+01 2.56e+02 1.60e+01 5.12e+02 8.00e+00 4.00e+00
     5.00e-01]
    
    ******************** expandable_storage_gb ********************
    [ 512.    0.  256. 1024.  128.  400.   32. 2048.   64.]
    
    ******************** brand ********************
    ['Redmi' 'Realme' 'Tecno' 'POCO' 'Infinix' 'OPPO' 'Motorola' 'Vivo'
     'Samsung' 'iQOO' 'Nokia' 'Honor' 'Lava' 'Asus' 'OnePlus' 'Panasonic' 'Mi'
     'Huawei' 'Itel' 'LG' 'Gionee' 'XOLO' 'Moto' 'Lenovo' 'Karbonn' 'Kenxinda'
     'Google' 'Micromax' 'Celkon' 'VOTO' 'Meizu' 'Coolpad' 'Alcatel'
     'Mobiistar' 'Forme' 'Blackbear' 'Yu' 'Black' 'InFocus' 'MI3' 'Ringme'
     'Intex' 'Gome' 'Voto' 'LYF' 'Nextbit']
    
    ******************** color ********************
    ['Ruby Red' 'Aqua Blue' 'Forest Green' 'Diamond Blue' 'Diamond Black'
     'Diamond Sapphire' 'Diamond Ruby' 'Sapphire Blue' 'Onyx Black'
     'Ice Jadeite' 'Volcano Grey' 'Comet Blue' 'Phoenix Red' 'Violet'
     'Ocean Wave' 'Lunar White' 'Eclipse Black' 'Space Purple'
     'Moonlight White' 'So White' 'So Blue' 'Midnight Black'
     'Green and Greener' 'Blue' 'Out of the Blue' 'Ocean Blue' 'Burgundy Red'
     'Comet White' 'Agate Red' 'Sparkling Blue' 'Shadow Black' 'Crystal Green'
     'Chroma White' 'Lake Green' 'Sky White' 'Fusion Blue' 'Phantom Purple'
     'Mineral Blue' 'Two Shades of Black' 'Arctic White' 'Thunder Black'
     'Pearl Blue' 'Gold' 'Green' 'Fantasy White' 'Mystery Black' 'Sea Blue'
     'Blazing Blue' 'Lightening Black' 'Fusion Black' 'Iris Blue'
     'Dazzle Blue' 'Emerald Black' 'Black' 'Matrix Purple' 'Crystal Red'
     'Crystal Blue' 'Crystal Purple' 'Vanilla Mint' 'Emerald Green'
     'Lightning Blue' 'Lightning Red' 'Atlantis Blue' 'Aqua Green'
     'Pebble Grey' 'Piano Black' 'Gamma Green' 'Electric Blue' 'Silky White'
     'Glacier Blue' 'Midnight Grey' 'Flame Red' 'Space Black' 'Pearl Green'
     'Sonic Black' 'Carbon Black' 'Fascinating Purple' 'Pearl White'
     'Sonic Blue' 'Red' 'Magnetic Black' 'Dreamy White' 'Jazzy Blue'
     'Quantum Silver' 'Marine Green' 'Deep Blue' 'Neptune Blue'
     'Prism Crush Black' 'Phantom Black' 'Twilight Black' 'Mystic Silver'
     'White' 'Space Blue' 'Prism Crush Blue' 'Sand' 'Charcoal' 'Metallic Blue'
     'Unicorn White' 'Raven Black' 'Midnight Blue' 'SHOAL GOLD' 'Aurora Blue'
     'Interstellar Black' 'Mystic Black' 'Marine Blue' 'Berry Red' 'Garlic'
     'Lightning Orange' 'Halo White' 'Amber Red' 'Stream White'
     'Glacier White' 'Spring White' 'Super Polar White' 'Frosted Silver'
     'Concrete' 'fusion black' 'Ice Jadite' 'Tornado Black' 'Frost Blue'
     'Skyline Blue' 'Polar White' 'Starry Night' 'Volcano Orange' 'Red Brick'
     'Flowing Silver' 'Ocean Green' 'Alpha Grey' 'Dark Grey' 'Glaze Black'
     'Prism Black' '5G) (Tornado Black' 'Prism Blue' 'Glacial Green'
     'Prism Crush White' 'Jewelry White' 'Aura Black' 'Quetzal Cyan'
     'More Than White' 'Steel Blue' 'Charcoal Black' 'Cosmic Purple'
     'Shark Grey' 'Prime Black' 'Elegant Blue' 'Aura Glow' 'Armoured Edition'
     'Cyan Green' 'Waterfall Grey' 'Coral Green' 'Prism Crush Red'
     'Not just Blue' 'Aurora Green' 'Prism White' 'Bordeaux Red' 'Astral Blue'
     'Haze Blue' 'Blue Ocean' 'Kind of Grey' 'Midnight Ocean Black'
     'Prism Crush Silver' 'Glacier Ice White' 'Peacock Blue' 'Steel'
     'Gradation Ice Blue' 'Gradation Phantom Black' 'Nebula Purple'
     'Auroral Blue' 'Fluorite Purple' 'Marble Green' 'Bold Red' 'Diamond Red'
     'Glacier ice white' 'Lake Blue' 'Graphite Black' 'Thunder Blue'
     'Topaz Blue' 'Posh Black' 'Cosmic Gray' 'Rust Red' 'Mystic Bronze'
     'Tempered Blue' 'Polished Graphite' 'Champagne Gold' 'Gradation Purple'
     'Gradation Blue' 'Gradation Sea Blue' 'White and Silver' 'Nitro Blue'
     'Carbon Grey' 'Radiant Mist' 'Black and Gold' 'Clearly White' 'Black Sea'
     'Platinum' 'Grey' 'Jet Black' 'Black&Grey' 'Copper' 'Luminous Black'
     'Matte Black' 'Sky Blue' 'Radiant Blue' 'Cosmic Black' 'Glacier Grey'
     'Silver' 'Aura Red' 'Spectrum Gold' 'Prism Crush Violet' 'Admiral Blue'
     'Just Black' 'Tradew Gray' 'Milan Black' 'Purple' 'Lemonade Blue'
     'Twilight Purple' 'Dynamic Black' 'Cloud Blue' 'Vacation Blue'
     'Haze Crush Silver' 'Champagne' 'Rose Gold' 'Lightning Purple'
     '2nd Generation) (Black Leather' '2nd Generation) (Black' 'Rosso Red'
     'Astro Moonlight White' 'Sunset Red' 'City Blue' 'Iron' 'Prism Rose'
     'Elektric Blue' 'Black & Silver' 'Midnight Purple' 'Yellow'
     'Bubblegum Pink' 'Metallic Grey' 'Charcoal Grey' 'Hillier Purple'
     'BLUEM/Blue' 'White/WHITEM' 'Lilac Purple' 'Coral Blue' 'Polar Gold'
     'White Gold' 'Red&Black' 'Coal Black' 'Titan' 'Nebula Red' 'Fine Gold'
     'Pyramid Gold' 'Nile Blue' 'Gold/GoldM' 'Racing Black' 'Serene Gold'
     'Sandstone Black' 'Space Gray' 'Sprite' 'Ice' 'New 2016 Edition) (White'
     'New 2016 Edition) (Black' 'Ice Lake' 'Rich Cranberry' 'Maple Wood'
     'Mirror Black' '4G) (White' 'Matte Blue' 'Prestige Gold' 'Caribbean Blue'
     'Dark Gray' 'Charcoal Blue' 'Nebula Blue' 'Matte Gold' 'Ember'
     'Mocha Gold']
    
    ******************** storage_in_name ********************
    [ 64. 128.  32. 256.  16. 512.   8.   4.  nan]
    
    ******************** model_name ********************
    ['Redmi 8' 'Realme 5i' 'Realme C2' 'Tecno Spark Power 2' 'Realme C3'
     'Realme 6' 'POCO X2' 'Infinix Hot 9' 'Realme 6i' 'OPPO A9 2020'
     'Motorola One Fusion+' 'Realme Narzo 10A' 'Infinix Smart 4 Plus'
     'POCO M2 Pro' 'OPPO A5s' 'Vivo Y91i' 'Vivo Y12' 'Vivo Y15' 'Vivo Y11'
     'Realme 5 Pro' 'Infinix Hot 9 Pro' 'Redmi Note 8 Pro' 'OPPO Reno2 F'
     'Vivo Z1x' 'Realme X3' 'Vivo U10' 'Realme X2' 'OPPO A31' 'Redmi 8A Dual'
     'OPPO F15' 'Vivo Y50' 'Vivo Y30' 'OPPO A12' 'Realme 5s' 'Realme 6 Pro'
     'Infinix S5 Pro' 'Redmi Note 9' 'Vivo V19' 'OPPO Reno4 Pro'
     'Redmi K20 Pro' 'Samsung Galaxy M31' 'Vivo Z1Pro' 'Samsung Galaxy M01'
     'Tecno Camon 15' 'OPPO A1K' 'Samsung Galaxy M11' 'Vivo Y19' 'Vivo S1 Pro'
     'iQOO 3' 'OPPO A11K' 'Realme X2 Pro' 'Samsung Galaxy A31'
     'Samsung Galaxy A80' 'OPPO A52' 'Samsung Galaxy A21s' 'Realme X'
     'Nokia 2.3' 'Redmi Note 7 Pro' 'Samsung Galaxy A51' 'Honor 9X'
     'Samsung Galaxy M21' 'Realme X3 SuperZoom' 'Redmi Note 9 Pro' 'Lava Z66'
     'Asus ROG Phone 3' 'Lava Z61 Pro' 'Redmi Note 9 Pro Max'
     'Redmi Note 6 Pro' 'OnePlus 7T' 'Tecno Camon 15 Pro' 'Vivo X50'
     'Samsung M01 core' 'Vivo S1' 'OPPO Reno3 Pro' 'OPPO Reno 10x Zoom'
     'OPPO Reno4 Pro Special Edition' 'Vivo X50 Pro' 'OPPO F11 Pro' 'Redmi Y2'
     'Samsung Galaxy J2 Core' 'Samsung Galaxy S10 Lite' 'OnePlus 8'
     'Panasonic ELUGA I6' 'Realme XT' 'OPPO F11' 'Samsung Galaxy Note10 Lite'
     'Asus ROG Phone II' 'Infinix Hot 8' 'Mi A3' 'POCO F1'
     'Samsung Galaxy A71' 'Samsung Galaxy A10s' 'Panasonic Eluga I8' 'Mi A2'
     'Redmi 8A' 'Redmi Y3' 'Huawei Y9 Prime 2019' 'Nokia 7.2' 'Mi 10'
     'Samsung Galaxy A70s' 'Realme 5' 'Asus ZenFone Max M1'
     'Infinix Note 5 Stylus' 'OPPO K1' 'Samsung Galaxy S9' 'OnePlus 7T Pro'
     'Realme 2 Pro' 'Panasonic Eluga Ray 610' 'Redmi K20' 'Honor 20'
     'Samsung Galaxy M30s' 'Vivo V17' 'Vivo V17Pro' 'Huawei P30 Lite'
     'Samsung Galaxy A50' 'Nokia 3.2' 'Itel A23' 'Vivo Y93' 'Realme 3i'
     'Redmi Note 5 Pro' 'Samsung Galaxy S8' 'LG G8X' 'Redmi 5A'
     'Samsung Galaxy A30s' 'Gionee F9 Plus' 'LG W30' 'Vivo NEX'
     'Gionee S11 Lite' 'Vivo V15 Pro' 'XOLO ERA 3X' 'Lava Z61'
     'Samsung Galaxy S20+' 'Realme X50 Pro' 'Redmi Note 7'
     'Samsung Galaxy Note 20 Ultra 5G' 'Nokia 5' 'Moto E6s' 'Lenovo X2-AP'
     'Lenovo K10 Plus' 'Samsung Galaxy On Max' 'Asus Zenfone Max Pro M1'
     'Honor 9i' 'Itel A25' 'Karbonn A52 plus' 'Redmi Note 7S' 'Realme 3 Pro'
     'Samsung Galaxy S9 Plus' 'Kenxinda P8' 'OPPO R17 Pro' 'Nokia 3.1 Plus'
     'Gionee P7 Max' 'Gionee F205' 'Google Pixel 3a' 'Lava Z41'
     'Samsung Galaxy Note 20' 'LG G7+ ThinQ' 'Micromax Canvas 2 2018'
     'Celkon Cliq 2' 'Asus Zenfone 4 Selfie' 'VOTO V11' 'Redmi 6 Pro'
     'Micromax Canvas Infinity' 'OPPO Find X' 'OPPO Reno2 Z'
     'Samsung Galaxy A50s' 'Nokia 6.1 Plus' 'Vivo V7+' 'Samsung Galaxy A20s'
     'Samsung Galaxy S10e' 'Meizu C9 Pro' 'Samsung Galaxy S10'
     'Samsung Galaxy S10 Plus' 'Coolpad Mega 5M' 'Lenovo Z2 Plus'
     'Honor 10 Lite' 'Realme 3' 'Asus ZenFone Max M2' 'Honor 9 Lite'
     'Redmi Note 5' 'Gionee A1' 'Alcatel 3V' 'Tecno Camon i 2'
     'Infinix Smart 2' 'Honor 9x Pro' 'Mobiistar C1' 'Panasonic P101'
     'Forme R7' 'Infinix Hot S3X' 'Blackbear B6 Glory' 'Nokia 4.2'
     'OPPO Reno2' 'OPPO A3s' 'Gionee Marathon M5 Plus' 'Samsung Galaxy A9'
     'Infinix S4' 'Nokia 3' 'Tecno Spark Go Plus' 'Gionee F205 Pro'
     'Asus Zenfone 2 Laser ZE500KL' 'Yu Yunique 2 Plus' 'Lava Z62'
     'Micromax Bharat Go' 'Moto X' 'Micromax Vdeo 3' 'Gionee F103 Pro'
     'Micromax Canvas Music M1' 'OPPO A9' 'Black Shark 2' 'Nokia 6.1'
     'Lava Z53' 'Yu Ace' 'Lava A55' 'Samsung Galaxy A30' 'Panasonic P100'
     'InFocus M535' 'LG W30 Pro' 'Lenovo K3 Note' 'Infinix Hot 7' 'Vivo Y71'
     'Honor 8 Lite' 'Redmi Go' 'MI3' 'Redmi Note 4' 'Honor 9N'
     'Samsung Galaxy A7' 'Panasonic P88' 'Lenovo K9' 'Meizu M5' 'Lava A82'
     'Lava A68' 'Redmi 6A' 'Lenovo A5' 'Vivo X21' 'Karbonn A40 Indian'
     'Redmi 7A' 'Micromax Vdeo 2' 'Gionee F10' 'Lava P7+' 'Honor Play'
     'Ringme Me8 pro' 'Vivo V9 Pro' 'OPPO F7' 'Karbonn Aura Power 4G+'
     'Intex Aqua Lions X1' 'Samsung Galaxy S20 Ultra' 'Gome C7 Note'
     'Nokia 2.2' 'OPPO A83' 'Honor 6 Plus' 'XOLO ERA 1X Pro' 'Gionee S10 Lite'
     'Voto V2' 'LG K9 4G LTE' 'Voto V2i' 'Vivo Y81' 'OPPO F5 Youth'
     'Yu Yunique 2' 'Motorola One Macro' 'Lenovo K9 Note' 'LG G Pro 2'
     'Micromax Canvas Xpress A99' 'Panasonic Eluga Ray 530' 'Ringme ME 10 Pro'
     'Panasonic Eluga A3' 'Lenovo VIBE P1' 'Moto C Plus'
     'XOLO ERA 2-4G with VoLTE' 'Samsung Galaxy On Nxt' 'Panasonic P55 Novo'
     'Vivo U20' 'Moto M' 'Panasonic Eluga L 4G' 'LG V30+' 'Samsung Galaxy J5'
     'Gionee S6 Pro' 'Gionee X1s' 'LYF Water 4' 'Lava Z71'
     'Google Pixel 3a XL' 'Samsung Galaxy J5 - 6' 'Samsung Galaxy J7 Duo'
     'LYF Water 10' 'Redmi 6' 'Micromax Bolt Q381' 'Vivo V9 Youth'
     'Samsung Galaxy On5' 'Micromax Canvas 5 Lite-Special Edition'
     'Micromax Bharat 5 Infinity Edition' 'Asus Zenfone 3s Max'
     'Micromax Canvas 2 Colors A120' 'Nokia 8.1' 'OPPO A5 2020'
     'Micromax Dual 4' 'Asus ZenFone Max Pro M2' 'Moto One' 'Lenovo K8'
     'Samsung Galaxy J1' 'Realme 2' 'InFocus M812i' 'Honor 8X' 'Honor 8x'
     'Lava X41 Plus' 'Panasonic P110' 'OnePlus 8 Pro'
     'Samsung Galaxy J7 Prime 2' 'POCO X2 Special Edition'
     'Samsung Galaxy On7' 'Lava Z81' 'Samsung Galaxy A2 Core' 'Vivo Y81i'
     'Lava Iris Atom X' 'Lava Z93' 'XOLO ZX' 'Samsung Galaxy On8'
     'Gionee A1 Plus' 'Gionee P5L' 'Nextbit Robin' 'XOLO Omega 5.0']
    
    ******************** is_pro ********************
    [0 1]
    
    ******************** is_plus ********************
    [0 1]
    
    ******************** is_max ********************
    [0 1]
    
    ******************** is_ultra ********************
    [0 1]
    
    ******************** is_lite ********************
    [0 1]
    
    ******************** is_prime ********************
    [0 1]
    
    ******************** is_core ********************
    [0 1]
    
    ******************** is_zoom ********************
    [0 1]
    
    ******************** is_5g ********************
    [0 1]
    
    ******************** review_count ********************
    [5.50780e+04 2.00620e+04 1.00910e+04 6.76740e+04 2.35800e+03 5.64100e+03
     8.87700e+03 4.31800e+03 1.75780e+04 2.26300e+03 5.32000e+02 1.95300e+03
     4.14000e+03 2.58400e+03 3.20400e+03 2.17000e+03 1.66700e+03 4.21000e+02
     1.72100e+03 5.88000e+02 1.69800e+03 1.21000e+03 1.71400e+03 2.74000e+03
     4.05000e+02 7.22300e+03 9.97800e+03 1.76000e+03 5.30900e+03 2.10000e+02
     1.60780e+04 2.29500e+03 1.01000e+02 2.59900e+03 4.40500e+03 8.40000e+02
     1.70000e+02 3.10000e+02 1.90000e+01 2.37000e+02 8.90000e+01 9.94000e+02
     7.70000e+01 2.43230e+04 7.06200e+03 3.99100e+03 1.59500e+03 1.37780e+04
     5.32200e+03 3.50000e+01 4.70000e+02 3.80000e+01 8.00700e+03 7.80000e+01
     2.19000e+02 1.46590e+04 4.34000e+02 2.06000e+02 3.06000e+02 1.08900e+03
     4.68000e+02 3.93000e+02 3.95500e+03 1.46600e+04 5.76000e+02 7.68000e+02
     2.51000e+02 3.98000e+02 1.04800e+03 1.16900e+03 1.63300e+03 2.20000e+02
     9.55000e+02 3.60000e+02 6.18000e+02 1.57000e+02 4.23000e+02 1.32190e+04
     5.07300e+03 8.20000e+01 4.44000e+02 2.52170e+04 5.65000e+02 1.39000e+02
     1.10000e+01 2.25400e+03 1.05000e+02 2.40000e+03 3.43880e+04 1.00000e+00
     3.60000e+01 2.05000e+02 3.10000e+01 2.30000e+01 1.08310e+04 2.03600e+03
     7.04000e+02 7.21000e+02 3.90000e+01 2.40000e+01 5.00000e+00 1.76000e+02
     5.36150e+04 2.16000e+02 1.54000e+02 1.27000e+02 1.60000e+01 6.40000e+01
     1.15060e+04 1.86700e+03 7.31000e+02 1.70700e+03 1.74000e+02 1.88400e+03
     2.61600e+03 4.40000e+01 1.88000e+02 1.70000e+01 5.99000e+02 1.21380e+04
     8.76100e+03 3.41000e+02 1.41000e+02 1.91800e+03 3.50990e+04 1.13600e+03
     3.10200e+03 1.11000e+02 7.00000e+01 2.50000e+02 7.32000e+02 1.07730e+04
     1.50500e+03 4.50000e+01 9.00000e+01 8.65400e+03 6.11000e+02 1.02000e+02
     2.12450e+04 3.62000e+02 7.64300e+03 2.33100e+03 2.96690e+04 4.20000e+01
     4.72700e+03 7.14000e+02 5.08500e+03 3.30000e+02 2.99400e+03 2.99000e+02
     6.80000e+02 5.98000e+02 0.00000e+00 5.97600e+03 9.10000e+01 8.00000e+00
     2.85000e+02 2.56160e+04 6.41700e+03 1.23821e+05 7.59000e+03 3.58700e+03
     2.00000e+00 6.53750e+04 3.20000e+02 1.53238e+05 2.98000e+02 6.25000e+02
     1.08000e+02 7.97800e+03 9.50000e+01 5.51000e+02 2.80000e+03 1.25300e+03
     3.92000e+02 5.00000e+01 2.99000e+04 1.42120e+04 2.25000e+02 1.67000e+02
     6.38300e+03 9.05000e+02 3.67000e+02 2.15320e+04 5.20000e+01 9.60000e+02
     2.83500e+03 3.72100e+04 1.07000e+02 1.04080e+04 3.00000e+00 5.55000e+02
     3.35280e+04 1.44730e+04 3.62500e+03 3.40000e+01 7.60000e+01 1.65000e+02
     4.57000e+02 1.15800e+03 4.89000e+02 9.34000e+02 1.40000e+01 8.78000e+02
     3.62480e+04 1.20000e+01 4.13900e+03 7.96000e+02 2.09700e+03 5.21000e+02
     7.79000e+02 2.62740e+04 1.40000e+02 2.70600e+03 1.77010e+04 1.98000e+02
     1.75000e+02 1.26000e+02 7.10000e+01 9.72000e+02 1.32300e+03 4.35490e+04
     1.26490e+04 6.63690e+04 1.21190e+04 3.99730e+04 2.63530e+04 1.02800e+03
     3.57000e+02 8.00000e+01 4.01300e+03 8.84000e+02 9.20000e+02 2.59000e+03
     1.52000e+02 1.99100e+03 4.35880e+04 2.70000e+01 3.92300e+03 1.30100e+03
     1.64770e+04 3.30000e+01 9.61000e+02 1.07400e+03 1.34200e+03 3.91000e+02
     9.00000e+02 1.19400e+03 2.83000e+02 3.36000e+02 3.86000e+02 3.45700e+03
     7.00000e+00 6.80000e+01 8.19000e+03 1.50000e+01 1.42200e+03 2.93000e+02
     1.00760e+04 6.60000e+01 2.00000e+01 2.45330e+04 3.47400e+03 4.15000e+02
     9.15000e+02 9.58000e+02 1.31230e+04 5.14200e+03 1.11861e+05 2.20150e+04
     2.13490e+04 2.00000e+02 1.83000e+03 5.02000e+02 1.72000e+02 1.83000e+02
     3.66600e+03 9.64000e+02 2.94000e+02 1.64980e+04 6.76600e+03 2.80800e+03
     2.76700e+04 1.31400e+03 4.95000e+02 2.94900e+03 3.80000e+02 5.30000e+01
     2.38900e+03 2.88000e+02 1.69000e+02 7.98000e+02 5.59000e+02 1.45000e+02
     9.60000e+01 1.97000e+02 1.19100e+03 7.16910e+04 3.67600e+03 2.15100e+03
     1.29000e+02 7.50000e+01 6.48000e+02 4.04060e+04 1.63400e+03 2.57700e+03
     3.27700e+03 5.46840e+04 1.92900e+03 5.53510e+04 1.85000e+02 1.33430e+04
     4.49000e+02 2.29000e+03 4.83000e+02 3.39000e+02 1.00000e+01 2.29000e+02
     1.77520e+04 3.43000e+02 5.14000e+02 4.05850e+04 6.75000e+02 1.00380e+04
     4.46380e+04 2.92600e+03 2.70170e+04 6.70000e+02 5.15800e+03 7.47000e+02
     1.37200e+03 1.86000e+02 1.09980e+04 5.60000e+01 3.55000e+02 2.61000e+02
     4.99530e+04 4.10000e+01 7.34000e+02 4.70000e+01 2.72600e+04 1.26900e+03
     2.43000e+02 7.36000e+02 2.55500e+04 2.59000e+02 2.52000e+02 1.30000e+01
     8.02600e+03 7.10000e+02 1.95500e+03 2.01000e+02 5.16000e+02 8.10000e+01]
    
    

----

### Univariate Non Visual statistical Analysis


```python
def discrete_univariate_analysis(cat_column):
    for col_name in cat_col:
        print("*"*10, col_name, "*"*10)
        print(cat_col[col_name].agg(['count', 'nunique', 'unique']))
        print('Value Counts: \n', cat_col[col_name].value_counts())
        print()
```


```python
def numerical_univariate_analysis(num_column):
    for col_name in num_col:
        print("*"*10, col_name, "*"*10)
        print(num_col[col_name].agg(['count', 'min', 'max', 'mean', 'median', 'std', 'skew']))
        print()
```


```python
discrete_univariate_analysis(cat_col)
```

    ********** processor_brand **********
    count                                                    838
    nunique                                                    7
    unique     [snapdragon, mediatek, other, exynos, kirin, u...
    Name: processor_brand, dtype: object
    Value Counts: 
     processor_brand
    snapdragon    409
    mediatek      235
    other          75
    exynos         70
    kirin          30
    spreadtrum     14
    unisoc          5
    Name: count, dtype: int64
    
    ********** processor_series **********
    count                                                    838
    nunique                                                   25
    unique     [400, 600, p22, g70, g90, 700, unknown, p70, 8...
    Name: processor_series, dtype: object
    Value Counts: 
     processor_series
    unknown    278
    600        133
    700         86
    800         70
    400         65
    p22         56
    9000        31
    p70         29
    g90         18
    p35         14
    7000        10
    g85          8
    g70          8
    p60          8
    p65          7
    p95          5
    p25          3
    p10          2
    3000         1
    p15          1
    8000         1
    200          1
    p90          1
    p23          1
    p20          1
    Name: count, dtype: int64
    
    ********** processor_type **********
    count                   838
    nunique                   2
    unique     [normal, gaming]
    Name: processor_type, dtype: object
    Value Counts: 
     processor_type
    normal    726
    gaming    112
    Name: count, dtype: int64
    
    ********** core_type **********
    count                        838
    nunique                        3
    unique     [unknown, octa, quad]
    Name: core_type, dtype: object
    Value Counts: 
     core_type
    unknown    589
    octa       189
    quad        60
    Name: count, dtype: int64
    
    ********** camera_type **********
    count                               838
    nunique                               4
    unique     [dual, quad, triple, single]
    Name: camera_type, dtype: object
    Value Counts: 
     camera_type
    dual      270
    single    234
    quad      188
    triple    146
    Name: count, dtype: int64
    
    ********** resolution_type **********
    count                                                    838
    nunique                                                    8
    unique     [hd_plus, full_hd, unknown, hd, fwvga, quad_hd...
    Name: resolution_type, dtype: object
    Value Counts: 
     resolution_type
    full_hd    395
    hd_plus    248
    hd          82
    unknown     66
    quad_hd     23
    fwvga       16
    wvga         6
    hvga         2
    Name: count, dtype: int64
    
    ********** brand **********
    count                                                    838
    nunique                                                   46
    unique     [Redmi, Realme, Tecno, POCO, Infinix, OPPO, Mo...
    Name: brand, dtype: object
    Value Counts: 
     brand
    Realme       134
    Samsung      121
    Redmi        113
    OPPO          77
    Vivo          73
    Honor         29
    Lava          28
    Infinix       25
    POCO          23
    Nokia         22
    Gionee        21
    Asus          20
    Lenovo        15
    Panasonic     14
    Micromax      13
    Mi            12
    Moto           9
    OnePlus        9
    LG             9
    Tecno          8
    XOLO           8
    iQOO           5
    Yu             5
    Itel           5
    Karbonn        4
    Google         4
    Meizu          4
    Ringme         4
    Motorola       2
    InFocus        2
    Voto           2
    Huawei         2
    Forme          2
    LYF            2
    Gome           1
    Intex          1
    MI3            1
    VOTO           1
    Black          1
    Blackbear      1
    Mobiistar      1
    Alcatel        1
    Coolpad        1
    Celkon         1
    Kenxinda       1
    Nextbit        1
    Name: count, dtype: int64
    
    ********** color **********
    count                                                    838
    nunique                                                  275
    unique     [Ruby Red, Aqua Blue, Forest Green, Diamond Bl...
    Name: color, dtype: object
    Value Counts: 
     color
    Black                 92
    Blue                  44
    Gold                  36
    Midnight Black        20
    Sapphire Blue         12
                          ..
    5G) (Tornado Black     1
    Glaze Black            1
    Alpha Grey             1
    Ocean Green            1
    Mocha Gold             1
    Name: count, Length: 275, dtype: int64
    
    ********** model_name **********
    count                                                    838
    nunique                                                  318
    unique     [Redmi 8, Realme 5i, Realme C2, Tecno Spark Po...
    Name: model_name, dtype: object
    Value Counts: 
     model_name
    Realme C2             14
    Realme X2             11
    POCO F1               10
    Redmi 8A Dual         10
    Realme X2 Pro          8
                          ..
    Yu Yunique 2 Plus      1
    Micromax Bharat Go     1
    Micromax Vdeo 3        1
    Gionee F103 Pro        1
    XOLO Omega 5.0         1
    Name: count, Length: 318, dtype: int64
    
    

####Observation
##### processor_brand
**Observation**
Snapdragon has the highest count in the dataset.
MediaTek is the second most common processor brand.
Exynos and Kirin have comparatively fewer phones.
Unisoc and Spreadtrum appear very less.

**Business Insight**
Most phones in the dataset are using Snapdragon processors.
The dataset mainly focuses on mid-range and popular Android phones.
Less occurrence of Unisoc and Spreadtrum indicates fewer low-end phones in the dataset.

##### camera_type
**Observation**
Dual camera phones are highest.
Single camera phones are also significant.
Triple and quad camera phones are comparatively lower.

**Business Insight**
The dataset contains both old budget phones and newer multi-camera phones.
Dual camera setup seems to be the most common market trend in this dataset.

##### resolution_type
**Observation**
full_hd has the highest count.
hd_plus is second highest.
quad_hd appears very less.

**Business Insight**
Most phones in the dataset belong to mid-range category.
Quad HD displays are mostly present in premium phones, so their count is low.
##### brand
**Observation**
Realme, Samsung, and Redmi dominate the dataset.
Many brands have very low counts.

**Business Insight**
The dataset strongly reflects the Indian smartphone market.
Budget and mid-range brands dominate the dataset.
Rare brands may not contribute much during modeling because of very few samples.

##### model_name
**Observation**
Many model names are unique.
Few models like Realme C2 and POCO F1 repeat multiple times.

**Business Insight**
The dataset contains many different smartphone models.
Some models have multiple variants/storage combinations.
Model name may create too many unique categories during ML modeling.

### price
**Observation**
Price ranges from ₹1,999 to ₹1,04,999.
Mean price (~₹16.3K) is greater than median (~₹12.9K).
High positive skewness (2.8).

**Business Insight**
Most phones in the dataset belong to budget and mid-range categories.
Few premium flagship phones are increasing the average price.
Dataset is not evenly distributed across all price ranges.
### rating
**Observation**
Ratings are mostly concentrated between 4.0 and 4.5.
Mean and median are very close.
Negative skewness (-1.75).

**Business Insight**
Most phones in the dataset have good customer ratings.
Very poorly rated phones are fewer.
Customers generally rate smartphones positively.


### battery_capacity
**Observation**
Battery capacity ranges from 1300mAh to 6000mAh.
Median is 4000mAh.
Distribution is nearly balanced.

**Business Insight**
Most phones in the dataset provide large battery capacities.
Modern smartphones are heavily centered around 4000–5000mAh batteries.
### display_size_inch
**Observation**
Display size ranges from 3.5 inch to 7 inch.
Median is 6.26 inch.
Negative skewness exists.

**Business Insight**
Most phones in the dataset are large-screen smartphones.
Small-screen phones are very few.
### ram_gb
**Observation**
RAM ranges from 0.25GB to 12GB.
Median is 4GB.
Slight positive skewness.

**Business Insight**
Majority of phones are mid-range devices with 4GB RAM.
High RAM phones exist but are fewer.
### rom_gb
**Observation**
Storage ranges from 0.5GB to 512GB.
Median is 64GB.
Strong positive skewness.
Business Insight
Most phones in the dataset provide 64GB storage.
Very high storage phones are comparatively fewer.

**Business Insight**
Extracted storage from name aligns closely with internal storage.
This feature may be redundant with rom_gb.

### review_count
**Observation**
Review counts vary from 0 to more than 1.5 lakh.
Median is much smaller than mean.
Very high positive skewness.

**Business Insight**
Few highly popular phones dominate review counts.
Most phones have comparatively fewer customer reviews.
Dataset contains some highly successful mass-market devices.


```python
save_path = r"C:\Users\Rithish\Desktop\graph"

os.makedirs(save_path, exist_ok=True)

# ------------------------------------------
# LOOP
# ------------------------------------------

for col in num_cols:

    # create figure
    plt.figure(figsize=(8,5))

    # plot
    sns.histplot(df[col], kde=True)

    plt.title(f"{col} Distribution")

    # --------------------------------------
    # SAVE BEFORE SHOW
    # --------------------------------------

    plt.savefig(
        rf"{save_path}\{col}.png",
        dpi=300,
        bbox_inches="tight"
    )

    # now show
    plt.show()

    # close
    plt.close()
```

    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_1.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_3.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_5.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_7.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_9.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_11.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_13.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_15.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_17.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_19.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_21.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_23.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_25.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_27.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_29.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_31.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_33.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_35.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_37.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_39.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_41.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_43.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_45.png)
    


    C:\Users\Rithish\.anaconda\kkk\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_62_47.png)
    



```python
save_path = r"C:\Users\Rithish\Desktop\graph"
for col in num_cols:

    # create figure
    plt.figure(figsize=(10,5))

    # boxplot
    sns.boxplot(x=df[col])

    # title
    plt.title(f"Boxplot of {col}")

    # --------------------------------------
    # SAVE GRAPH
    # --------------------------------------

    plt.savefig(
        rf"{save_path}\{col}.png",
        dpi=300,
        bbox_inches="tight"
    )

    # show
    plt.show()

    # close
    plt.close()
```


    
![png](output_63_0.png)
    



    
![png](output_63_1.png)
    



    
![png](output_63_2.png)
    



    
![png](output_63_3.png)
    



    
![png](output_63_4.png)
    



    
![png](output_63_5.png)
    



    
![png](output_63_6.png)
    



    
![png](output_63_7.png)
    



    
![png](output_63_8.png)
    



    
![png](output_63_9.png)
    



    
![png](output_63_10.png)
    



    
![png](output_63_11.png)
    



    
![png](output_63_12.png)
    



    
![png](output_63_13.png)
    



    
![png](output_63_14.png)
    



    
![png](output_63_15.png)
    



    
![png](output_63_16.png)
    



    
![png](output_63_17.png)
    



    
![png](output_63_18.png)
    



    
![png](output_63_19.png)
    



    
![png](output_63_20.png)
    



    
![png](output_63_21.png)
    



    
![png](output_63_22.png)
    



    
![png](output_63_23.png)
    



```python
def skew_spread(data):
    for i in data:
        print('*'*20, i, '*'*20)
        print(f"skewness of {i} ",data[i].skew())
        print(f"std of {i} ",data[i].std())
        print()

skew_spread(num_cols)
```

    ******************** price ********************
    skewness of price  2.806972349384207
    std of price  12965.135410691417
    
    ******************** rating ********************
    skewness of rating  -1.7520457897978494
    std of rating  0.24809193815614988
    
    ******************** rear_cam_1 ********************
    skewness of rear_cam_1  0.9703273520537854
    std of rear_cam_1  20.734169991924333
    
    ******************** rear_cam_2 ********************
    skewness of rear_cam_2  2.151141906807741
    std of rear_cam_2  4.853349604235419
    
    ******************** rear_cam_3 ********************
    skewness of rear_cam_3  1.967972298389585
    std of rear_cam_3  3.3838390674816106
    
    ******************** rear_cam_4 ********************
    skewness of rear_cam_4  2.789075892971413
    std of rear_cam_4  1.1859339576115686
    
    ******************** front_camera ********************
    skewness of front_camera  0.8229545635423106
    std of front_camera  9.395288400637265
    
    ******************** rear_camera_count ********************
    skewness of rear_camera_count  0.27680510732703284
    std of rear_camera_count  1.110943435222854
    
    ******************** battery_capacity ********************
    skewness of battery_capacity  -0.33212692268973215
    std of battery_capacity  845.3038637060607
    
    ******************** display_size_inch ********************
    skewness of display_size_inch  -1.4288064618101608
    std of display_size_inch  0.5438598696587958
    
    ******************** ram_gb ********************
    skewness of ram_gb  0.69680029938206
    std of ram_gb  2.2830820416289495
    
    ******************** rom_gb ********************
    skewness of rom_gb  2.1399217832725976
    std of rom_gb  67.31569811697057
    
    ******************** expandable_storage_gb ********************
    skewness of expandable_storage_gb  3.278847746194845
    std of expandable_storage_gb  345.3082111399747
    
    ******************** storage_in_name ********************
    skewness of storage_in_name  2.143590332700933
    std of storage_in_name  67.28360647692323
    
    ******************** is_pro ********************
    skewness of is_pro  1.7318425309538303
    std of is_pro  0.3784999967540181
    
    ******************** is_plus ********************
    skewness of is_plus  4.4458489104560295
    std of is_plus  0.2055570525432857
    
    ******************** is_max ********************
    skewness of is_max  4.6655377004683
    std of is_max  0.19741618023716748
    
    ******************** is_ultra ********************
    skewness of is_ultra  14.39605616229751
    std of is_ultra  0.06896492729080386
    
    ******************** is_lite ********************
    skewness of is_lite  5.2019202383407315
    std of is_lite  0.1798195004356632
    
    ******************** is_prime ********************
    skewness of is_prime  14.396056162297503
    std of is_prime  0.06896492729080386
    
    ******************** is_core ********************
    skewness of is_core  10.823211386533583
    std of is_core  0.09106778919985975
    
    ******************** is_zoom ********************
    skewness of is_zoom  12.8529049184574
    std of is_zoom  0.07705889277895867
    
    ******************** is_5g ********************
    skewness of is_5g  16.65320859822776
    std of is_5g  0.05976117485916115
    
    ******************** review_count ********************
    skewness of review_count  4.163851848104084
    std of review_count  15884.610802741618
    
    

### price

**Distribution**
Highly Right Skewed

Observation

Price ranges from ₹1,999 to ₹1,04,999.
Mean price (~₹16.3K) is greater than median (~₹12.9K).
Most phones are concentrated in lower price ranges.
Few expensive phones create many outliers.

Business Insight

Dataset mainly contains budget and mid-range smartphones.
Premium flagship phones are fewer in number.
Expensive phones increase the overall average price.

### rating

**Distribution**
Left Skewed

Observation

Ratings are mostly concentrated between 4.0 and 4.5.
Mean and median are very close.
Very low-rated phones are limited.

Business Insight

Most smartphones in the dataset receive good customer feedback.
Customers generally show positive satisfaction toward smartphones.

### battery_capacity

**Distribution**
Slight Left Skew / Near Normal

Observation

Battery capacity ranges from 1300mAh to 6000mAh.
Most phones are concentrated around 4000–5000mAh.
Very low battery phones appear as outliers.

Business Insight

Large battery backup has become standard in smartphones.
Modern phones mainly focus on higher battery capacity.

### display_size_inch

**Distribution**
Left Skewed

Observation

Display sizes mainly range between 6 and 6.5 inches.
Smaller display phones are fewer.
Large-screen devices dominate the dataset.

Business Insight

Customers prefer larger screen smartphones.
Compact smartphones are less common in the dataset.

### ram_gb

**Distribution**
Right Skewed

Observation

4GB RAM phones are most common.
Higher RAM phones appear less frequently.
Few premium phones create outliers.

Business Insight

Mid-range RAM configurations dominate the market.
Premium high-performance phones are comparatively fewer.

### rom_gb

**Distribution**
Highly Right Skewed

Observation

64GB storage appears most frequently.
Very high storage variants are fewer.
Storage values spread widely across the dataset.

Business Insight

Standard storage variants dominate smartphone sales.
Ultra-high storage models belong mainly to premium categories.

### front_camera

**Distribution**
Right Skewed

Observation

Most front cameras lie between 8MP and 16MP.
Very high selfie cameras are uncommon.
Few premium selfie phones create outliers.

Business Insight

Moderate selfie camera quality dominates the dataset.
Premium selfie-focused devices are limited.


### eview_count

**Distribution**
Extremely Right Skewed

Observation

Most phones have lower review counts.
Few phones contain extremely high reviews.
Large outliers are visible in the dataset.

Business Insight

Only few devices dominate customer popularity and sales.
Majority of phones receive moderate market attention.



```python

```

------


```python

```


```python
def discrete_univariate_analysis(discrete_data):
    for col_name in discrete_data:
        print("\n" + "="*60)
        print(f"UNIVARIATE ANALYSIS : {col_name}")
        print("="*60)
        print(discrete_data[col_name].agg(['count', 'nunique', 'unique']))
        print('Value Counts: \n', discrete_data[col_name].value_counts())
        print(f"\nMost Frequent Value : { discrete_data[col_name].mode()[0]}")
        print("\nPercentage Distribution:\n")
        print(round(df[col].value_counts(normalize=True) * 100,2))
        print()
```


```python
discrete_univariate_analysis(cat_col)
```

    
    ============================================================
    UNIVARIATE ANALYSIS : processor_brand
    ============================================================
    count                                                    838
    nunique                                                    7
    unique     [snapdragon, mediatek, other, exynos, kirin, u...
    Name: processor_brand, dtype: object
    Value Counts: 
     processor_brand
    snapdragon    409
    mediatek      235
    other          75
    exynos         70
    kirin          30
    spreadtrum     14
    unisoc          5
    Name: count, dtype: int64
    
    Most Frequent Value : snapdragon
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : processor_series
    ============================================================
    count                                                    838
    nunique                                                   25
    unique     [400, 600, p22, g70, g90, 700, unknown, p70, 8...
    Name: processor_series, dtype: object
    Value Counts: 
     processor_series
    unknown    278
    600        133
    700         86
    800         70
    400         65
    p22         56
    9000        31
    p70         29
    g90         18
    p35         14
    7000        10
    g85          8
    g70          8
    p60          8
    p65          7
    p95          5
    p25          3
    p10          2
    3000         1
    p15          1
    8000         1
    200          1
    p90          1
    p23          1
    p20          1
    Name: count, dtype: int64
    
    Most Frequent Value : unknown
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : processor_type
    ============================================================
    count                   838
    nunique                   2
    unique     [normal, gaming]
    Name: processor_type, dtype: object
    Value Counts: 
     processor_type
    normal    726
    gaming    112
    Name: count, dtype: int64
    
    Most Frequent Value : normal
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : core_type
    ============================================================
    count                        838
    nunique                        3
    unique     [unknown, octa, quad]
    Name: core_type, dtype: object
    Value Counts: 
     core_type
    unknown    589
    octa       189
    quad        60
    Name: count, dtype: int64
    
    Most Frequent Value : unknown
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : camera_type
    ============================================================
    count                               838
    nunique                               4
    unique     [dual, quad, triple, single]
    Name: camera_type, dtype: object
    Value Counts: 
     camera_type
    dual      270
    single    234
    quad      188
    triple    146
    Name: count, dtype: int64
    
    Most Frequent Value : dual
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : resolution_type
    ============================================================
    count                                                    838
    nunique                                                    8
    unique     [hd_plus, full_hd, unknown, hd, fwvga, quad_hd...
    Name: resolution_type, dtype: object
    Value Counts: 
     resolution_type
    full_hd    395
    hd_plus    248
    hd          82
    unknown     66
    quad_hd     23
    fwvga       16
    wvga         6
    hvga         2
    Name: count, dtype: int64
    
    Most Frequent Value : full_hd
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : brand
    ============================================================
    count                                                    838
    nunique                                                   46
    unique     [Redmi, Realme, Tecno, POCO, Infinix, OPPO, Mo...
    Name: brand, dtype: object
    Value Counts: 
     brand
    Realme       134
    Samsung      121
    Redmi        113
    OPPO          77
    Vivo          73
    Honor         29
    Lava          28
    Infinix       25
    POCO          23
    Nokia         22
    Gionee        21
    Asus          20
    Lenovo        15
    Panasonic     14
    Micromax      13
    Mi            12
    Moto           9
    OnePlus        9
    LG             9
    Tecno          8
    XOLO           8
    iQOO           5
    Yu             5
    Itel           5
    Karbonn        4
    Google         4
    Meizu          4
    Ringme         4
    Motorola       2
    InFocus        2
    Voto           2
    Huawei         2
    Forme          2
    LYF            2
    Gome           1
    Intex          1
    MI3            1
    VOTO           1
    Black          1
    Blackbear      1
    Mobiistar      1
    Alcatel        1
    Coolpad        1
    Celkon         1
    Kenxinda       1
    Nextbit        1
    Name: count, dtype: int64
    
    Most Frequent Value : Realme
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : color
    ============================================================
    count                                                    838
    nunique                                                  275
    unique     [Ruby Red, Aqua Blue, Forest Green, Diamond Bl...
    Name: color, dtype: object
    Value Counts: 
     color
    Black                 92
    Blue                  44
    Gold                  36
    Midnight Black        20
    Sapphire Blue         12
                          ..
    5G) (Tornado Black     1
    Glaze Black            1
    Alpha Grey             1
    Ocean Green            1
    Mocha Gold             1
    Name: count, Length: 275, dtype: int64
    
    Most Frequent Value : Black
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    
    ============================================================
    UNIVARIATE ANALYSIS : model_name
    ============================================================
    count                                                    838
    nunique                                                  318
    unique     [Redmi 8, Realme 5i, Realme C2, Tecno Spark Po...
    Name: model_name, dtype: object
    Value Counts: 
     model_name
    Realme C2             14
    Realme X2             11
    POCO F1               10
    Redmi 8A Dual         10
    Realme X2 Pro          8
                          ..
    Yu Yunique 2 Plus      1
    Micromax Bharat Go     1
    Micromax Vdeo 3        1
    Gionee F103 Pro        1
    XOLO Omega 5.0         1
    Name: count, Length: 318, dtype: int64
    
    Most Frequent Value : Realme C2
    
    Percentage Distribution:
    
    review_count
    0.0        1.43
    10091.0    0.95
    20062.0    0.95
    55078.0    0.84
    1.0        0.84
               ... 
    1028.0     0.12
    39973.0    0.12
    972.0      0.12
    126.0      0.12
    81.0       0.12
    Name: proportion, Length: 354, dtype: float64
    
    


```python
cat_col
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>processor_brand</th>
      <th>processor_series</th>
      <th>processor_type</th>
      <th>core_type</th>
      <th>camera_type</th>
      <th>resolution_type</th>
      <th>brand</th>
      <th>color</th>
      <th>model_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
      <td>unknown</td>
      <td>dual</td>
      <td>hd_plus</td>
      <td>Redmi</td>
      <td>Ruby Red</td>
      <td>Redmi 8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>quad</td>
      <td>hd_plus</td>
      <td>Realme</td>
      <td>Aqua Blue</td>
      <td>Realme 5i</td>
    </tr>
    <tr>
      <th>2</th>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>quad</td>
      <td>hd_plus</td>
      <td>Realme</td>
      <td>Aqua Blue</td>
      <td>Realme 5i</td>
    </tr>
    <tr>
      <th>3</th>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>quad</td>
      <td>hd_plus</td>
      <td>Realme</td>
      <td>Forest Green</td>
      <td>Realme 5i</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>dual</td>
      <td>hd_plus</td>
      <td>Realme</td>
      <td>Diamond Blue</td>
      <td>Realme C2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>978</th>
      <td>other</td>
      <td>unknown</td>
      <td>normal</td>
      <td>quad</td>
      <td>single</td>
      <td>hd</td>
      <td>Gionee</td>
      <td>Gold</td>
      <td>Gionee P5L</td>
    </tr>
    <tr>
      <th>980</th>
      <td>snapdragon</td>
      <td>800</td>
      <td>normal</td>
      <td>unknown</td>
      <td>single</td>
      <td>full_hd</td>
      <td>Nextbit</td>
      <td>Ember</td>
      <td>Nextbit Robin</td>
    </tr>
    <tr>
      <th>981</th>
      <td>mediatek</td>
      <td>p25</td>
      <td>normal</td>
      <td>unknown</td>
      <td>dual</td>
      <td>full_hd</td>
      <td>Gionee</td>
      <td>Mocha Gold</td>
      <td>Gionee A1 Plus</td>
    </tr>
    <tr>
      <th>982</th>
      <td>mediatek</td>
      <td>unknown</td>
      <td>normal</td>
      <td>unknown</td>
      <td>single</td>
      <td>hd</td>
      <td>XOLO</td>
      <td>Black</td>
      <td>XOLO Omega 5.0</td>
    </tr>
    <tr>
      <th>983</th>
      <td>exynos</td>
      <td>9000</td>
      <td>normal</td>
      <td>unknown</td>
      <td>single</td>
      <td>quad_hd</td>
      <td>Samsung</td>
      <td>Midnight Black</td>
      <td>Samsung Galaxy S9</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 9 columns</p>
</div>




```python
save_path=rf"C:\Users\Rithish\Desktop\cat_graphs"
for col in cat_col:

    print("\n" + "="*60)
    print(f"VISUAL ANALYSIS : {col}")
    print("="*60)
    plt.figure(figsize=(12,5))
    sns.countplot(x=df[col],order=df[col].value_counts().index)
    plt.title(f"Countplot of {col}")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(rf"{save_path}\{col}.png",dpi=300,bbox_inches="tight")
    plt.show()
    plt.close()
```

    
    ============================================================
    VISUAL ANALYSIS : processor_brand
    ============================================================
    


    
![png](output_72_1.png)
    


    
    ============================================================
    VISUAL ANALYSIS : processor_series
    ============================================================
    


    
![png](output_72_3.png)
    


    
    ============================================================
    VISUAL ANALYSIS : processor_type
    ============================================================
    


    
![png](output_72_5.png)
    


    
    ============================================================
    VISUAL ANALYSIS : core_type
    ============================================================
    


    
![png](output_72_7.png)
    


    
    ============================================================
    VISUAL ANALYSIS : camera_type
    ============================================================
    


    
![png](output_72_9.png)
    


    
    ============================================================
    VISUAL ANALYSIS : resolution_type
    ============================================================
    


    
![png](output_72_11.png)
    


    
    ============================================================
    VISUAL ANALYSIS : brand
    ============================================================
    


    
![png](output_72_13.png)
    


    
    ============================================================
    VISUAL ANALYSIS : color
    ============================================================
    


    
![png](output_72_15.png)
    


    
    ============================================================
    VISUAL ANALYSIS : model_name
    ============================================================
    


    
![png](output_72_17.png)
    



```python
target = df_new["price"]
```

### Bi_variate 


```python

target = "price"
save_path = r"C:\Users\Rithish\Desktop\bivariate_graphs"
os.makedirs(save_path, exist_ok=True)
for col in num_cols:
    print("\n" + "="*60)
    print(f"BIVARIATE ANALYSIS : {col} vs {target}")
    print("="*60)
    corr_value = df_new[col].corr(df_new[target])
    print(f"\nCorrelation : {round(corr_value, 3)}")
    plt.figure(figsize=(8,5))
    sns.regplot(
        x=df_new[col],
        y=df_new[target],
        scatter_kws={'alpha':0.5}
    )
    plt.title(f"{col} vs {target}")
    plt.savefig(
        rf"{save_path}\{col}_vs_price.png",
        dpi=300,
        bbox_inches="tight"
    )
    plt.show()
    plt.close()



for col in cat_col:
    print("\n" + "="*60)
    print(f"BIVARIATE ANALYSIS : {col} vs {target}")
    print("="*60)
    print(
        df_new.groupby(col)[target]
        .agg(['count', 'mean', 'median', 'min', 'max'])
        .sort_values(by='mean', ascending=False)
    ) 
    plt.figure(figsize=(12,5))
    sns.boxplot(
        x=df_new[col],
        y=df_new[target]
    )
    plt.title(f"{col} vs {target}")
    plt.xticks(rotation=45) 
    plt.tight_layout()
    plt.savefig(
        rf"{save_path}\{col}_vs_price.png",
        dpi=300,
        bbox_inches="tight"
    )
    plt.show()
    plt.close()
```

    
    ============================================================
    BIVARIATE ANALYSIS : price vs price
    ============================================================
    
    Correlation : 1.0
    


    
![png](output_75_1.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : rating vs price
    ============================================================
    
    Correlation : 0.442
    


    
![png](output_75_3.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : rear_cam_1 vs price
    ============================================================
    
    Correlation : 0.549
    


    
![png](output_75_5.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : rear_cam_2 vs price
    ============================================================
    
    Correlation : 0.683
    


    
![png](output_75_7.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : rear_cam_3 vs price
    ============================================================
    
    Correlation : 0.579
    


    
![png](output_75_9.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : rear_cam_4 vs price
    ============================================================
    
    Correlation : 0.242
    


    
![png](output_75_11.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : front_camera vs price
    ============================================================
    
    Correlation : 0.442
    


    
![png](output_75_13.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : rear_camera_count vs price
    ============================================================
    
    Correlation : 0.404
    


    
![png](output_75_15.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : battery_capacity vs price
    ============================================================
    
    Correlation : 0.23
    


    
![png](output_75_17.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : display_size_inch vs price
    ============================================================
    
    Correlation : 0.45
    


    
![png](output_75_19.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : ram_gb vs price
    ============================================================
    
    Correlation : 0.749
    


    
![png](output_75_21.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : rom_gb vs price
    ============================================================
    
    Correlation : 0.683
    


    
![png](output_75_23.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : expandable_storage_gb vs price
    ============================================================
    
    Correlation : 0.156
    


    
![png](output_75_25.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : storage_in_name vs price
    ============================================================
    
    Correlation : 0.682
    


    
![png](output_75_27.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_pro vs price
    ============================================================
    
    Correlation : 0.088
    


    
![png](output_75_29.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_plus vs price
    ============================================================
    
    Correlation : 0.065
    


    
![png](output_75_31.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_max vs price
    ============================================================
    
    Correlation : -0.123
    


    
![png](output_75_33.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_ultra vs price
    ============================================================
    
    Correlation : 0.455
    


    
![png](output_75_35.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_lite vs price
    ============================================================
    
    Correlation : 0.114
    


    
![png](output_75_37.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_prime vs price
    ============================================================
    
    Correlation : -0.019
    


    
![png](output_75_39.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_core vs price
    ============================================================
    
    Correlation : -0.069
    


    
![png](output_75_41.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_zoom vs price
    ============================================================
    
    Correlation : 0.098
    


    
![png](output_75_43.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : is_5g vs price
    ============================================================
    
    Correlation : 0.317
    


    
![png](output_75_45.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : review_count vs price
    ============================================================
    
    Correlation : -0.171
    


    
![png](output_75_47.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : processor_brand vs price
    ============================================================
                     count          mean   median   min     max
    processor_brand                                            
    exynos              70  33997.000000  23999.0  5280  104999
    snapdragon         409  18296.251834  14999.0  3990   60990
    kirin               30  16214.033333  15999.0  7999   26499
    mediatek           235  11582.531915   9999.0  2499   29990
    other               75   7406.120000   5999.0  2850   41999
    unisoc               5   5392.800000   5499.0  3690    6499
    spreadtrum          14   4246.785714   3620.0  1999    7499
    


    
![png](output_75_49.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : processor_series vs price
    ============================================================
                      count          mean   median    min     max
    processor_series                                             
    8000                  1  49990.000000  49990.0  49990   49990
    800                  70  33298.600000  31999.0   8250   60990
    p95                   5  28790.000000  27990.0  27990   29990
    p90                   1  27490.000000  27490.0  27490   27490
    9000                 31  26318.483871  24999.0  14082   65900
    700                  86  20849.046512  18499.0  12999   49990
    p65                   7  17847.142857  18990.0  14990   19990
    g90                  18  16359.555556  16994.0  12999   18999
    p70                  29  15957.689655  16990.0   8499   24990
    g85                   8  15868.000000  15877.5  13999   17498
    7000                 10  15317.900000  18450.0   5280   19900
    p10                   2  14499.000000  14499.0   7499   21499
    600                 133  14405.112782  11999.0   7339   39000
    unknown             278  14201.773381   8939.0   1999  104999
    p35                  14  12671.142857  11994.5   9990   14999
    p25                   3  12332.333333  10499.0   9999   16499
    p20                   1  11499.000000  11499.0  11499   11499
    p60                   8  11496.750000  10499.0   8499   19990
    p23                   1  10999.000000  10999.0  10999   10999
    p15                   1   9999.000000   9999.0   9999    9999
    g70                   8   9499.000000   9499.0   8999    9999
    400                  65   8850.061538   8299.0   3990   22221
    p22                  56   8796.571429   8424.5   5699   12990
    3000                  1   8192.000000   8192.0   8192    8192
    200                   1   5749.000000   5749.0   5749    5749
    


    
![png](output_75_51.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : processor_type vs price
    ============================================================
                    count          mean   median    min     max
    processor_type                                             
    gaming            112  27370.348214  22999.0  12999   59990
    normal            726  14666.214876  11490.0   1999  104999
    


    
![png](output_75_53.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : core_type vs price
    ============================================================
               count          mean   median   min     max
    core_type                                            
    unknown      589  17572.264856  14290.0  1999   97999
    octa         189  15912.227513  12490.0  4999  104999
    quad          60   5927.933333   5499.0  2850   13999
    


    
![png](output_75_55.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : camera_type vs price
    ============================================================
                 count          mean   median   min     max
    camera_type                                            
    triple         146  24816.027397  17990.0  4990  104999
    quad           188  21520.292553  18926.0  9999   49990
    dual           270  14493.966667  11000.0  5699   65200
    single         234   9106.089744   6894.5  1999   65900
    


    
![png](output_75_57.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : resolution_type vs price
    ============================================================
                     count          mean   median   min     max
    resolution_type                                            
    quad_hd             23  56540.304348  57800.0  5280  104999
    full_hd            395  20205.954430  17499.0  3199   77999
    unknown             66  19583.151515  17989.5  2499   49999
    hd_plus            248   9991.322581   9744.5  3999   19990
    hd                  82   6920.695122   6077.0  2850   22221
    fwvga               16   4210.375000   4049.0  2999    6999
    wvga                 6   3357.000000   3349.0  1999    5896
    hvga                 2   3015.500000   3015.5  2741    3290
    


    
![png](output_75_59.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : brand vs price
    ============================================================
               count          mean   median    min     max
    brand                                                 
    OnePlus        9  44765.444444  44999.0  34834   59990
    iQOO           5  38790.000000  37990.0  34990   44990
    Google         4  32999.000000  32999.0  30999   34999
    Black          1  31999.000000  31999.0  31999   31999
    Samsung      121  28317.214876  19900.0   5280  104999
    LG             9  22767.111111  20999.0   4999   54990
    Nextbit        1  19999.000000  19999.0  19999   19999
    POCO          23  19107.695652  18999.0  13999   22999
    OPPO          77  18782.428571  16490.0   6490   60990
    Huawei         2  18449.000000  18449.0  16899   19999
    Vivo          73  18086.219178  16990.0   7880   49990
    Mi            12  17005.333333  14499.0   9188   49990
    Realme       134  15946.208955  14999.0   6499   41999
    Honor         29  15810.793103  15999.0   7999   26499
    MI3            1  13999.000000  13999.0  13999   13999
    Motorola       2  13749.000000  13749.0   9999   17499
    Moto           9  13332.333333   9999.0   6999   24999
    Asus          20  12973.550000   8999.0   5990   49999
    Redmi        113  12530.654867  10999.0   4499   29999
    Nokia         22  10111.909091   9237.5   5290   18099
    Lenovo        15  10029.066667   9899.0   6499   17499
    Tecno          8   9642.875000   9999.0   5999   14999
    Infinix       25   9491.000000   9599.0   7499   11499
    Gionee        21   9121.190476   6999.0   3999   26999
    Meizu          4   7994.500000   7994.5   6990    8999
    XOLO           8   6855.625000   6630.0   3999   11199
    Celkon         1   6789.000000   6789.0   6789    6789
    InFocus        2   6194.500000   6194.5   4889    7500
    Alcatel        1   5999.000000   5999.0   5999    5999
    Micromax      13   5722.461538   5749.0   3199    9005
    Yu             5   5499.000000   4999.0   4799    6699
    Ringme         4   5498.750000   5499.0   5498    5499
    Panasonic     14   5423.500000   5344.5   3990    8440
    Intex          1   4999.000000   4999.0   4999    4999
    Forme          2   4999.000000   4999.0   3999    5999
    LYF            2   4999.000000   4999.0   4999    4999
    Blackbear      1   4999.000000   4999.0   4999    4999
    Gome           1   4990.000000   4990.0   4990    4990
    Lava          28   4980.642857   5274.5   1999    8499
    Voto           2   4661.500000   4661.5   4199    5124
    Itel           5   4305.600000   3999.0   3750    4999
    Mobiistar      1   3990.000000   3990.0   3990    3990
    VOTO           1   3690.000000   3690.0   3690    3690
    Kenxinda       1   3199.000000   3199.0   3199    3199
    Karbonn        4   3032.250000   3015.5   2499    3599
    Coolpad        1   2850.000000   2850.0   2850    2850
    


    
![png](output_75_61.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : color vs price
    ============================================================
                      count     mean   median    min     max
    color                                                   
    Mystic Bronze         2  91499.0  91499.0  77999  104999
    Cosmic Black          2  87999.0  87999.0  77999   97999
    Cosmic Gray           2  87999.0  87999.0  77999   97999
    Cloud Blue            1  77899.0  77899.0  77899   77899
    Mystic Black          2  62494.5  62494.5  19990  104999
    ...                 ...      ...      ...    ...     ...
    Black and Gold        2   3644.5   3644.5   3290    3999
    Black & Silver        1   3499.0   3499.0   3499    3499
    BLUEM/Blue            1   2999.0   2999.0   2999    2999
    White/WHITEM          1   2999.0   2999.0   2999    2999
    White and Silver      1   2741.0   2741.0   2741    2741
    
    [275 rows x 5 columns]
    


    
![png](output_75_63.png)
    


    
    ============================================================
    BIVARIATE ANALYSIS : model_name vs price
    ============================================================
                                     count           mean    median     min  \
    model_name                                                                
    Samsung Galaxy Note 20 Ultra 5G      2  104999.000000  104999.0  104999   
    Samsung Galaxy S20 Ultra             2   97999.000000   97999.0   97999   
    Samsung Galaxy Note 20               1   77999.000000   77999.0   77999   
    Samsung Galaxy S20+                  3   77965.666667   77999.0   77899   
    Samsung Galaxy S10 Plus              1   65200.000000   65200.0   65200   
    ...                                ...            ...       ...     ...   
    Karbonn A52 plus                     2    3015.500000    3015.5    2741   
    Lava A68                             3    2999.000000    2999.0    2999   
    Coolpad Mega 5M                      1    2850.000000    2850.0    2850   
    Karbonn A40 Indian                   1    2499.000000    2499.0    2499   
    Lava Iris Atom X                     2    1999.000000    1999.0    1999   
    
                                        max  
    model_name                               
    Samsung Galaxy Note 20 Ultra 5G  104999  
    Samsung Galaxy S20 Ultra          97999  
    Samsung Galaxy Note 20            77999  
    Samsung Galaxy S20+               77999  
    Samsung Galaxy S10 Plus           65200  
    ...                                 ...  
    Karbonn A52 plus                   3290  
    Lava A68                           2999  
    Coolpad Mega 5M                    2850  
    Karbonn A40 Indian                 2499  
    Lava Iris Atom X                   1999  
    
    [318 rows x 5 columns]
    


    
![png](output_75_65.png)
    


### battery_capacity vs price
**Relationship**
* Moderate Positive Relationship

**Observation**
* As battery capacity increases, price also slightly increases.
* Most expensive phones contain batteries around 4000–5000mAh.
* Relationship is not perfectly linear because some budget phones also provide large batteries.

**Business Insight**
* Battery capacity contributes to price, but it is not the only deciding factor.
* Brands now provide high battery even in mid-range devices.

### display_size_inch vs price
**Relationship**
* Strong Positive Relationship

**Observation**
* Larger displays generally have higher prices.
* Phones above 6.5 inches are mostly premium or mid-premium devices.
* Small display phones belong mainly to budget segments.

**Business Insight**
* Customers prefer larger displays for multimedia and gaming.
* Premium smartphones focus heavily on bigger displays.

### ram_gb vs price
**Relationship**
* Strong Positive Relationship

**Observation**
* Price increases significantly as RAM increases.
* 8GB and 12GB RAM phones belong mostly to premium categories.
* Low RAM phones remain in lower price ranges.

**Business Insight**
* RAM is one of the strongest pricing factors in smartphones.
* Higher RAM configurations directly indicate premium positioning.

### rom_gb vs price
**Relationship**
* strong Positive Relationship

**Observation**
* Higher internal storage strongly increases smartphone price.
* 256GB and 512GB variants are mostly expensive devices.
* 64GB storage dominates budget and mid-range phones.

**Business Insight**
* Storage capacity strongly affects pricing strategy.
* Premium smartphones focus on higher storage variants.

### front_camera vs price
**Relationship**
* Moderate Positive Relationship

**Observation**
* Higher selfie camera MP generally increases price.
* Premium selfie-focused phones show higher prices.
* Relationship contains some spread and outliers.

**Business Insight**
* Front camera quality contributes to smartphone pricing.
* Selfie features are important in mid-premium segments.

### rear_cam_1 vs price
**Relationship**
* Strong Positive Relationship

**Observation**
* Higher primary rear camera MP increases price.
* 48MP and 64MP cameras appear frequently in higher-priced phones.
* 108MP cameras belong mainly to premium devices.

**Business Insight**
* Camera quality is a major selling point in smartphones.
* Premium phones focus heavily on high-resolution main cameras.

### rating vs price
**Relationship**
* Moderate Positive Relationship

**observation**
* Higher-rated phones generally have higher prices.
* Premium devices tend to receive better customer ratings.

**Business Insight**
* Better product quality and experience increase customer satisfaction.

### camera_type vs price
**Relationship**
* Moderate Positive Relationship

**Observation**
* Triple and quad-camera phones generally have higher prices.
* Single-camera phones mostly belong to budget ranges.

**Business Insight**
* Multi-camera systems increase smartphone market value.

### resolution_type vs price
**Relationship**
* Strong Categorical Relationship

**Observation**
* uad HD displays belong mostly to premium smartphones.
* HD and FWVGA displays appear mainly in budget phones.

**Business Insight**
* Display quality strongly affects smartphone pricing.

### brand vs price
**Relationship**
* Strong Categorical Relationship

**Observation**
* Apple-like premium brands are absent, but Samsung, OnePlus, and Google variants appear costlier.
* Brands like Lava, Micromax, and Karbonn belong mostly to lower price ranges.

**Business Insight**
* Brand reputation strongly influences smartphone pricing strategy.

### Multivariate Analysis


```python
corr_matrix = num_cols.corr()
```


```python
corr_matrix
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>rating</th>
      <th>rear_cam_1</th>
      <th>rear_cam_2</th>
      <th>rear_cam_3</th>
      <th>rear_cam_4</th>
      <th>front_camera</th>
      <th>rear_camera_count</th>
      <th>battery_capacity</th>
      <th>display_size_inch</th>
      <th>...</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
      <th>review_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>price</th>
      <td>1.000000</td>
      <td>0.441990</td>
      <td>0.549360</td>
      <td>0.683156</td>
      <td>0.578605</td>
      <td>0.241662</td>
      <td>0.441981</td>
      <td>0.404045</td>
      <td>0.230259</td>
      <td>0.450062</td>
      <td>...</td>
      <td>0.087590</td>
      <td>0.065363</td>
      <td>-0.123071</td>
      <td>0.455026</td>
      <td>0.114048</td>
      <td>-0.019360</td>
      <td>-0.068573</td>
      <td>0.098257</td>
      <td>0.317487</td>
      <td>-0.170824</td>
    </tr>
    <tr>
      <th>rating</th>
      <td>0.441990</td>
      <td>1.000000</td>
      <td>0.399945</td>
      <td>0.416020</td>
      <td>0.291930</td>
      <td>0.241449</td>
      <td>0.413040</td>
      <td>0.503415</td>
      <td>0.548109</td>
      <td>0.701951</td>
      <td>...</td>
      <td>0.193354</td>
      <td>-0.081071</td>
      <td>-0.185484</td>
      <td>0.002531</td>
      <td>0.023081</td>
      <td>0.010601</td>
      <td>-0.005877</td>
      <td>0.004010</td>
      <td>0.015797</td>
      <td>0.205557</td>
    </tr>
    <tr>
      <th>rear_cam_1</th>
      <td>0.549360</td>
      <td>0.399945</td>
      <td>1.000000</td>
      <td>0.653917</td>
      <td>0.552818</td>
      <td>0.515119</td>
      <td>0.572901</td>
      <td>0.704851</td>
      <td>0.402463</td>
      <td>0.571095</td>
      <td>...</td>
      <td>0.252548</td>
      <td>-0.065401</td>
      <td>-0.125851</td>
      <td>0.271676</td>
      <td>-0.055727</td>
      <td>-0.044988</td>
      <td>-0.084772</td>
      <td>0.127453</td>
      <td>0.177285</td>
      <td>-0.132980</td>
    </tr>
    <tr>
      <th>rear_cam_2</th>
      <td>0.683156</td>
      <td>0.416020</td>
      <td>0.653917</td>
      <td>1.000000</td>
      <td>0.565451</td>
      <td>0.434533</td>
      <td>0.573086</td>
      <td>0.704887</td>
      <td>0.367800</td>
      <td>0.561685</td>
      <td>...</td>
      <td>0.198909</td>
      <td>-0.033029</td>
      <td>-0.123978</td>
      <td>0.360969</td>
      <td>0.046388</td>
      <td>-0.024535</td>
      <td>-0.089281</td>
      <td>0.068389</td>
      <td>0.094103</td>
      <td>-0.122204</td>
    </tr>
    <tr>
      <th>rear_cam_3</th>
      <td>0.578605</td>
      <td>0.291930</td>
      <td>0.552818</td>
      <td>0.565451</td>
      <td>1.000000</td>
      <td>0.363717</td>
      <td>0.471451</td>
      <td>0.600649</td>
      <td>0.294099</td>
      <td>0.433294</td>
      <td>...</td>
      <td>0.150149</td>
      <td>0.109474</td>
      <td>-0.104167</td>
      <td>0.204638</td>
      <td>0.070292</td>
      <td>-0.030864</td>
      <td>-0.054473</td>
      <td>0.137292</td>
      <td>0.183023</td>
      <td>-0.180849</td>
    </tr>
    <tr>
      <th>rear_cam_4</th>
      <td>0.241662</td>
      <td>0.241449</td>
      <td>0.515119</td>
      <td>0.434533</td>
      <td>0.363717</td>
      <td>1.000000</td>
      <td>0.382059</td>
      <td>0.695422</td>
      <td>0.290074</td>
      <td>0.326563</td>
      <td>...</td>
      <td>0.130118</td>
      <td>-0.100189</td>
      <td>-0.075450</td>
      <td>-0.032284</td>
      <td>-0.086671</td>
      <td>-0.032284</td>
      <td>-0.042784</td>
      <td>0.068472</td>
      <td>0.005773</td>
      <td>-0.107145</td>
    </tr>
    <tr>
      <th>front_camera</th>
      <td>0.441981</td>
      <td>0.413040</td>
      <td>0.572901</td>
      <td>0.573086</td>
      <td>0.471451</td>
      <td>0.382059</td>
      <td>1.000000</td>
      <td>0.588130</td>
      <td>0.338596</td>
      <td>0.550892</td>
      <td>...</td>
      <td>0.208546</td>
      <td>-0.067238</td>
      <td>-0.125848</td>
      <td>0.077256</td>
      <td>0.174474</td>
      <td>0.064159</td>
      <td>-0.095990</td>
      <td>0.118245</td>
      <td>-0.017343</td>
      <td>-0.122850</td>
    </tr>
    <tr>
      <th>rear_camera_count</th>
      <td>0.404045</td>
      <td>0.503415</td>
      <td>0.704851</td>
      <td>0.704887</td>
      <td>0.600649</td>
      <td>0.695422</td>
      <td>0.588130</td>
      <td>1.000000</td>
      <td>0.560013</td>
      <td>0.694919</td>
      <td>...</td>
      <td>0.222096</td>
      <td>-0.092686</td>
      <td>-0.150815</td>
      <td>0.040939</td>
      <td>-0.003725</td>
      <td>-0.021437</td>
      <td>-0.111073</td>
      <td>0.101622</td>
      <td>0.053428</td>
      <td>-0.099963</td>
    </tr>
    <tr>
      <th>battery_capacity</th>
      <td>0.230259</td>
      <td>0.548109</td>
      <td>0.402463</td>
      <td>0.367800</td>
      <td>0.294099</td>
      <td>0.290074</td>
      <td>0.338596</td>
      <td>0.560013</td>
      <td>1.000000</td>
      <td>0.783995</td>
      <td>...</td>
      <td>0.103714</td>
      <td>-0.016253</td>
      <td>-0.068475</td>
      <td>0.066825</td>
      <td>-0.061114</td>
      <td>-0.009004</td>
      <td>-0.126394</td>
      <td>0.021842</td>
      <td>0.038681</td>
      <td>0.057584</td>
    </tr>
    <tr>
      <th>display_size_inch</th>
      <td>0.450062</td>
      <td>0.701951</td>
      <td>0.571095</td>
      <td>0.561685</td>
      <td>0.433294</td>
      <td>0.326563</td>
      <td>0.550892</td>
      <td>0.694919</td>
      <td>0.783995</td>
      <td>1.000000</td>
      <td>...</td>
      <td>0.205145</td>
      <td>-0.056427</td>
      <td>-0.189774</td>
      <td>0.101691</td>
      <td>0.015968</td>
      <td>0.006448</td>
      <td>-0.164352</td>
      <td>0.067579</td>
      <td>0.071105</td>
      <td>-0.051211</td>
    </tr>
    <tr>
      <th>ram_gb</th>
      <td>0.749250</td>
      <td>0.534297</td>
      <td>0.715980</td>
      <td>0.718243</td>
      <td>0.578234</td>
      <td>0.420878</td>
      <td>0.668896</td>
      <td>0.660903</td>
      <td>0.402516</td>
      <td>0.651833</td>
      <td>...</td>
      <td>0.275876</td>
      <td>0.014676</td>
      <td>-0.121290</td>
      <td>0.227856</td>
      <td>0.076247</td>
      <td>-0.030135</td>
      <td>-0.134750</td>
      <td>0.173412</td>
      <td>0.197211</td>
      <td>-0.141056</td>
    </tr>
    <tr>
      <th>rom_gb</th>
      <td>0.683139</td>
      <td>0.451740</td>
      <td>0.582534</td>
      <td>0.607629</td>
      <td>0.502044</td>
      <td>0.339328</td>
      <td>0.531640</td>
      <td>0.559605</td>
      <td>0.324766</td>
      <td>0.538593</td>
      <td>...</td>
      <td>0.147826</td>
      <td>0.007610</td>
      <td>-0.124775</td>
      <td>0.115298</td>
      <td>0.115293</td>
      <td>-0.016467</td>
      <td>-0.084188</td>
      <td>0.143725</td>
      <td>0.156813</td>
      <td>-0.141831</td>
    </tr>
    <tr>
      <th>expandable_storage_gb</th>
      <td>0.155930</td>
      <td>0.133521</td>
      <td>0.034288</td>
      <td>0.145827</td>
      <td>0.041673</td>
      <td>0.004185</td>
      <td>0.081294</td>
      <td>0.080972</td>
      <td>0.264555</td>
      <td>0.210966</td>
      <td>...</td>
      <td>0.052704</td>
      <td>-0.031376</td>
      <td>0.342631</td>
      <td>0.147308</td>
      <td>0.161500</td>
      <td>-0.006813</td>
      <td>0.020150</td>
      <td>-0.053599</td>
      <td>0.068211</td>
      <td>0.020881</td>
    </tr>
    <tr>
      <th>storage_in_name</th>
      <td>0.682147</td>
      <td>0.450559</td>
      <td>0.581122</td>
      <td>0.606579</td>
      <td>0.501416</td>
      <td>0.338664</td>
      <td>0.529616</td>
      <td>0.558094</td>
      <td>0.320281</td>
      <td>0.538260</td>
      <td>...</td>
      <td>0.146815</td>
      <td>0.007014</td>
      <td>-0.125572</td>
      <td>0.115296</td>
      <td>0.114964</td>
      <td>-0.016691</td>
      <td>-0.084590</td>
      <td>0.143747</td>
      <td>0.156906</td>
      <td>-0.143383</td>
    </tr>
    <tr>
      <th>is_pro</th>
      <td>0.087590</td>
      <td>0.193354</td>
      <td>0.252548</td>
      <td>0.198909</td>
      <td>0.150149</td>
      <td>0.130118</td>
      <td>0.208546</td>
      <td>0.222096</td>
      <td>0.103714</td>
      <td>0.205145</td>
      <td>...</td>
      <td>1.000000</td>
      <td>-0.052243</td>
      <td>0.049837</td>
      <td>-0.031678</td>
      <td>-0.085046</td>
      <td>-0.031678</td>
      <td>-0.041982</td>
      <td>-0.035439</td>
      <td>-0.027418</td>
      <td>0.073409</td>
    </tr>
    <tr>
      <th>is_plus</th>
      <td>0.065363</td>
      <td>-0.081071</td>
      <td>-0.065401</td>
      <td>-0.033029</td>
      <td>0.109474</td>
      <td>-0.100189</td>
      <td>-0.067238</td>
      <td>-0.092686</td>
      <td>-0.016253</td>
      <td>-0.056427</td>
      <td>...</td>
      <td>-0.052243</td>
      <td>1.000000</td>
      <td>-0.044197</td>
      <td>-0.014884</td>
      <td>-0.039960</td>
      <td>-0.014884</td>
      <td>-0.019726</td>
      <td>-0.016651</td>
      <td>-0.012883</td>
      <td>-0.053938</td>
    </tr>
    <tr>
      <th>is_max</th>
      <td>-0.123071</td>
      <td>-0.185484</td>
      <td>-0.125851</td>
      <td>-0.123978</td>
      <td>-0.104167</td>
      <td>-0.075450</td>
      <td>-0.125848</td>
      <td>-0.150815</td>
      <td>-0.068475</td>
      <td>-0.189774</td>
      <td>...</td>
      <td>0.049837</td>
      <td>-0.044197</td>
      <td>1.000000</td>
      <td>-0.014242</td>
      <td>-0.004578</td>
      <td>-0.014242</td>
      <td>-0.018874</td>
      <td>-0.015932</td>
      <td>-0.012326</td>
      <td>0.018927</td>
    </tr>
    <tr>
      <th>is_ultra</th>
      <td>0.455026</td>
      <td>0.002531</td>
      <td>0.271676</td>
      <td>0.360969</td>
      <td>0.204638</td>
      <td>-0.032284</td>
      <td>0.077256</td>
      <td>0.040939</td>
      <td>0.066825</td>
      <td>0.101691</td>
      <td>...</td>
      <td>-0.031678</td>
      <td>-0.014884</td>
      <td>-0.014242</td>
      <td>1.000000</td>
      <td>-0.012876</td>
      <td>-0.004796</td>
      <td>-0.006356</td>
      <td>-0.005365</td>
      <td>0.575621</td>
      <td>-0.032357</td>
    </tr>
    <tr>
      <th>is_lite</th>
      <td>0.114048</td>
      <td>0.023081</td>
      <td>-0.055727</td>
      <td>0.046388</td>
      <td>0.070292</td>
      <td>-0.086671</td>
      <td>0.174474</td>
      <td>-0.003725</td>
      <td>-0.061114</td>
      <td>0.015968</td>
      <td>...</td>
      <td>-0.085046</td>
      <td>-0.039960</td>
      <td>-0.004578</td>
      <td>-0.012876</td>
      <td>1.000000</td>
      <td>-0.012876</td>
      <td>-0.017064</td>
      <td>-0.014405</td>
      <td>-0.011144</td>
      <td>0.023539</td>
    </tr>
    <tr>
      <th>is_prime</th>
      <td>-0.019360</td>
      <td>0.010601</td>
      <td>-0.044988</td>
      <td>-0.024535</td>
      <td>-0.030864</td>
      <td>-0.032284</td>
      <td>0.064159</td>
      <td>-0.021437</td>
      <td>-0.009004</td>
      <td>0.006448</td>
      <td>...</td>
      <td>-0.031678</td>
      <td>-0.014884</td>
      <td>-0.014242</td>
      <td>-0.004796</td>
      <td>-0.012876</td>
      <td>1.000000</td>
      <td>-0.006356</td>
      <td>-0.005365</td>
      <td>-0.004151</td>
      <td>-0.030142</td>
    </tr>
    <tr>
      <th>is_core</th>
      <td>-0.068573</td>
      <td>-0.005877</td>
      <td>-0.084772</td>
      <td>-0.089281</td>
      <td>-0.054473</td>
      <td>-0.042784</td>
      <td>-0.095990</td>
      <td>-0.111073</td>
      <td>-0.126394</td>
      <td>-0.164352</td>
      <td>...</td>
      <td>-0.041982</td>
      <td>-0.019726</td>
      <td>-0.018874</td>
      <td>-0.006356</td>
      <td>-0.017064</td>
      <td>-0.006356</td>
      <td>1.000000</td>
      <td>-0.007111</td>
      <td>-0.005501</td>
      <td>-0.040896</td>
    </tr>
    <tr>
      <th>is_zoom</th>
      <td>0.098257</td>
      <td>0.004010</td>
      <td>0.127453</td>
      <td>0.068389</td>
      <td>0.137292</td>
      <td>0.068472</td>
      <td>0.118245</td>
      <td>0.101622</td>
      <td>0.021842</td>
      <td>0.067579</td>
      <td>...</td>
      <td>-0.035439</td>
      <td>-0.016651</td>
      <td>-0.015932</td>
      <td>-0.005365</td>
      <td>-0.014405</td>
      <td>-0.005365</td>
      <td>-0.007111</td>
      <td>1.000000</td>
      <td>-0.004644</td>
      <td>-0.035636</td>
    </tr>
    <tr>
      <th>is_5g</th>
      <td>0.317487</td>
      <td>0.015797</td>
      <td>0.177285</td>
      <td>0.094103</td>
      <td>0.183023</td>
      <td>0.005773</td>
      <td>-0.017343</td>
      <td>0.053428</td>
      <td>0.038681</td>
      <td>0.071105</td>
      <td>...</td>
      <td>-0.027418</td>
      <td>-0.012883</td>
      <td>-0.012326</td>
      <td>0.575621</td>
      <td>-0.011144</td>
      <td>-0.004151</td>
      <td>-0.005501</td>
      <td>-0.004644</td>
      <td>1.000000</td>
      <td>-0.027799</td>
    </tr>
    <tr>
      <th>review_count</th>
      <td>-0.170824</td>
      <td>0.205557</td>
      <td>-0.132980</td>
      <td>-0.122204</td>
      <td>-0.180849</td>
      <td>-0.107145</td>
      <td>-0.122850</td>
      <td>-0.099963</td>
      <td>0.057584</td>
      <td>-0.051211</td>
      <td>...</td>
      <td>0.073409</td>
      <td>-0.053938</td>
      <td>0.018927</td>
      <td>-0.032357</td>
      <td>0.023539</td>
      <td>-0.030142</td>
      <td>-0.040896</td>
      <td>-0.035636</td>
      <td>-0.027799</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>24 rows × 24 columns</p>
</div>




```python
plt.figure(figsize=(14,10))

# heatmap
sns.heatmap(
    corr_matrix,
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)

plt.title("Correlation Heatmap")

plt.tight_layout()
plt.savefig(
        rf"{save_path}\{col}_vs_price.png",
        dpi=300,
        bbox_inches="tight"
    )
plt.show()
```


    
![png](output_80_0.png)
    



```python
df_new.isnull().sum()
```




    price                     0
    rating                    8
    processor_brand           0
    processor_series          0
    processor_type            0
    core_type                 0
    rear_cam_1                0
    rear_cam_2                0
    rear_cam_3                0
    rear_cam_4                0
    front_camera             24
    rear_camera_count         0
    camera_type               0
    battery_capacity          0
    display_size_inch         0
    resolution_type           0
    ram_gb                    0
    rom_gb                    0
    expandable_storage_gb     0
    brand                     0
    color                     0
    storage_in_name           2
    model_name                0
    is_pro                    0
    is_plus                   0
    is_max                    0
    is_ultra                  0
    is_lite                   0
    is_prime                  0
    is_core                   0
    is_zoom                   0
    is_5g                     0
    review_count              0
    dtype: int64




```python
df_new["front_camera"] = df_new["front_camera"].fillna(
    df_new["front_camera"].median()
)
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>rating</th>
      <th>processor_brand</th>
      <th>processor_series</th>
      <th>processor_type</th>
      <th>core_type</th>
      <th>rear_cam_1</th>
      <th>rear_cam_2</th>
      <th>rear_cam_3</th>
      <th>rear_cam_4</th>
      <th>...</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
      <th>review_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9999</td>
      <td>4.4</td>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>55078.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10999</td>
      <td>4.5</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>11999</td>
      <td>4.5</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11999</td>
      <td>4.5</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7499</td>
      <td>4.4</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10091.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 33 columns</p>
</div>




```python
# x is a feature 
x = df_new.drop("price", axis=1)

# y is the target variable 
y = df_new["price"]

```


```python
drop_cols = [
    "color",
    "model_name",
    "storage_in_name"
]
```


```python
df_new.drop([
    "color",
    "model_name",
    "storage_in_name"
],axis=1,inplace=True)
```


```python
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>rating</th>
      <th>processor_brand</th>
      <th>processor_series</th>
      <th>processor_type</th>
      <th>core_type</th>
      <th>rear_cam_1</th>
      <th>rear_cam_2</th>
      <th>rear_cam_3</th>
      <th>rear_cam_4</th>
      <th>...</th>
      <th>is_pro</th>
      <th>is_plus</th>
      <th>is_max</th>
      <th>is_ultra</th>
      <th>is_lite</th>
      <th>is_prime</th>
      <th>is_core</th>
      <th>is_zoom</th>
      <th>is_5g</th>
      <th>review_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9999</td>
      <td>4.4</td>
      <td>snapdragon</td>
      <td>400</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>55078.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10999</td>
      <td>4.5</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>11999</td>
      <td>4.5</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11999</td>
      <td>4.5</td>
      <td>snapdragon</td>
      <td>600</td>
      <td>normal</td>
      <td>unknown</td>
      <td>12.0</td>
      <td>8.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>20062.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7499</td>
      <td>4.4</td>
      <td>mediatek</td>
      <td>p22</td>
      <td>normal</td>
      <td>octa</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10091.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 30 columns</p>
</div>



# Final Conclusion

This project focused on analyzing smartphone specifications and their impact on product pricing. Extensive data cleaning, preprocessing, and feature engineering were performed to transform unstructured smartphone specifications into meaningful analytical features.

The analysis revealed that smartphone price is primarily influenced by hardware specifications such as RAM, internal storage, camera quality, processor type, and display characteristics. Premium smartphones generally combine multiple high-end specifications, while budget smartphones offer limited configurations at lower prices.

The dataset also showed that higher-priced devices tend to provide better overall hardware configurations rather than excelling in a single specification. Therefore, smartphone pricing is determined by the combined effect of multiple features rather than any individual feature alone.


# Feature Engineering Summary

Several new features were extracted from raw text columns to improve data quality and analytical value.

### Processor Features

* processor_brand
* processor_series
* processor_type
* core_type

### Camera Features

* rear_cam_1
* rear_cam_2
* rear_cam_3
* rear_cam_4
* front_camera
* rear_camera_count

### Battery Features

* battery_capacity

### Display Features

* display_size_inch
* resolution_type

### Memory Features

* ram_gb
* rom_gb
* expandable_storage_gb

### Name-Based Features

* brand
* storage_in_name
* model_name
* is_pro
* is_plus
* is_max
* is_ultra
* is_lite
* is_prime
* is_core
* is_zoom
* is_5g

### Review Features

* review_count

These engineered features transformed raw specifications into structured numerical and categorical variables suitable for analysis and future machine learning tasks.


# Correlation Findings & Business Insights

## Key Correlation Findings

* RAM showed the strongest positive correlation with price (0.75).
* ROM showed a strong positive correlation with price (0.68).
* Secondary camera specifications also showed strong correlation with price.
* Primary camera quality demonstrated a moderate-to-strong positive relationship with price.
* Display size and front camera quality showed moderate positive relationships with price.
* Battery capacity showed only a weak positive correlation with price.
* Review count showed a slight negative correlation with price.

## Business Insights

* Premium smartphones are mainly differentiated through higher RAM and storage configurations.
* Better camera systems significantly contribute to higher product pricing.
* Smartphones with larger displays generally belong to higher price segments.
* Battery capacity alone does not significantly increase smartphone price because large batteries are available across both budget and premium segments.
* Budget smartphones tend to generate higher review counts due to greater sales volume and wider market reach.
* Snapdragon-based smartphones dominate the market, indicating strong consumer preference and brand adoption.
* Full HD displays are the most commonly adopted display type across the smartphone market.
* Major brands such as Realme, Samsung, Redmi, OPPO, and Vivo dominate the dataset, reflecting their strong market presence.

## Final Insights

1. RAM is the most influential feature affecting smartphone price.
2. Storage capacity is one of the primary drivers of premium smartphone pricing.
3. Camera quality plays a significant role in smartphone market positioning.
4. Premium smartphones generally combine better RAM, storage, camera, and display specifications together.
5. Smartphone pricing is influenced by a combination of specifications rather than a single feature.
6. Budget devices dominate customer engagement, while premium devices focus on performance and advanced specifications.
7. Feature engineering significantly improved the quality of analysis by converting complex textual specifications into meaningful structured features.
8. The dataset clearly shows distinct segmentation between budget, mid-range, premium, and flagship smartphones.



```python

```
